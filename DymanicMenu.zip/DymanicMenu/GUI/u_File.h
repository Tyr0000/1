TCHAR *SelectFileToSave(HWND hOwnerWnd, TCHAR *DlgTitle, TCHAR *FileExts, TCHAR **ppShortFN);
TCHAR *SelectFileToOpen(HWND hOwnerWnd, TCHAR *DlgTitle, TCHAR *FileExts, TCHAR **ppShortFN= NULL);