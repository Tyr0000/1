//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DymanicMenu.rc
//
#define IDD_DLG_MAIN                    102
#define IDD_DLG_PARAMS_BUILDER          103
#define IDD_DLG_GRAPH_1D_BUILDER        104
#define IDD_DLG_TBL_BUILDER             105
#define IDD_DLG_DUMMY                   106
#define IDD_DLG_LOAD_DATA               107
#define IDD_DLG_GRAPH_2D_BUILDER        108
#define IDD_DLG_GRAPH_3D_BUILDER        109
#define IDD_DLGDATA1DGRAPH              110
#define IDR_MAINFRAME                   128
#define IDI_ICON_2D                     133
#define IDI_ICON_3D                     134
#define IDI_ICON_P                      135
#define IDI_ICON_R                      136
#define IDI_ICON_T                      137
#define IDD_DLG_GRAPH_2D                139
#define IDD_DLG_GRAPH_3D                140
#define IDD_DLG_TBL                     141
#define IDD_DLG_DATA_2D                 142
#define IDD_DLG_DATA_2D1                143
#define IDC_TREE_MENU_BUILDER           1000
#define IDC_BUTTON_ADD_MENU_ITEM        1001
#define IDC_BUTTON_DEL_MENU_ITEM        1002
#define IDC_LIST_FIELDS                 1003
#define IDC_TREE_MENU_TST               1003
#define IDC_RADIO_PARAMETER_DLG         1004
#define IDC_RADIO_TBL                   1005
#define IDC_RADIO_GRAPH                 1006
#define IDC_RADIO_2D_GRAPH              1007
#define IDC_RADIO_3D_GRAPH              1008
#define IDC_BUTTON_ADD_FIELD            1009
#define IDC_BUTTON_DEL_ALL_MENU_ITEMS   1010
#define IDC_BUTTON_DEL_FIELD            1011
#define IDC_BUTTON_MOVE_UP              1012
#define IDC_BUTTON_MOVE_DOWN            1013
#define IDC_BUTTON_SAVE_ITEMS           1014
#define IDC_BUTTON_IMPORT_ITEM          1015
#define IDC_BUTTON_LOAD_MENU            1016
#define IDC_EDIT_MENU_ITEM_NAME         1017
#define IDC_BUTTON_ADD_MENU_ROOT_ITEM   1018
#define IDC_STATIC_PLACEHOLDER_DLG      1019
#define IDC_BUTTON_TST                  1020
#define IDC_BUTTON_IMPORT_ITEM_DATA     1020
#define IDC_BUTTON_SAVE_DATA            1021
#define IDC_BUTTON_SAVE                 1022
#define IDC_COMBO_DATA_LEN              1023
#define IDC_BUTTON_EXPORT_ITEM          1023
#define IDC_BUTTON_LOAD_DATA            1024
#define IDC_BUTTON_LOAD                 1025
#define IDC_STATIC_MENU_NAME            1026
#define IDC_EDIT_NUM_OF_COLS            1027
#define IDC_EDIT_NUM_OF_ROWS            1028
#define IDC_LIST_DATA                   1029
#define IDC_EDIT_DATA_OFFSET_IN_FILE    1030
#define IDC_BUTTON1                     1031
#define IDC_EDIT_DATA_OFFSET            1032
#define IDC_EDIT_DATA_OFFSET_X          1033
#define IDC_EDIT_DATA_OFFSET_Y          1034
#define IDC_EDIT_MIN_VAL                1035
#define IDC_CHECK_SAVE_ITEMS            1036
#define IDC_LIST_DATA2                  1037
#define IDC_EDIT_DATA_OFFSET3           1038
#define IDC_EDIT_MAX_VAL                1039
#define IDC_CHECK_SAVE_DATA             1040
#define IDC_BUTTON_SAVE_DESCRIPTOR      1041
#define IDC_EDIT_NUM_OF_X               1042
#define IDC_BUTTON_IMPORT_DATA          1043
#define IDC_EDIT_NUM_OF_POINTS          1043
#define IDC_EDIT_NUM_OF_Y               1044
#define IDC_BUTTON_LOAD_EXT_MENU        1045
#define IDC_BUTTON_LOAD_FROM_CLIPBOARD  1046
#define IDC_BUTTON_TEST                 1047
#define IDC_BUTTON_SAVE_DESCRIPTOR2     1048
#define IDC_BUTTON_IMPORT               1048
#define IDC_BUTTON_IMPORT_ITEM_DATA2    1049
#define IDC_EDIT_IMPORT                 1050
#define IDC_EDIT_TITLE                  1051
#define IDC_BUTTON_IMPORT_MENU          1052
#define IDC_STATIC_TITLE                1053
#define IDC_EDIT_X_DATA_OFFSET          1054
#define IDC_EDIT_Y_DATA_OFFSET          1055
#define IDC_EDIT_X_AXIS                 1056
#define IDC_EDIT_NUM_Y_AXIS             1057
#define IDC_EDIT_X_MIN_VAL              1058
#define IDC_EDIT_X_MAX_VAL              1059
#define IDC_EDIT_X_MIN_VAL2             1060
#define IDC_EDIT_Y_MIN_VAL2             1060
#define IDC_EDIT_Y_MAX_VAL2             1061

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
