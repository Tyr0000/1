// DlgData1DGraph.cpp : implementation file
//

#include "stdafx.h"
#include "DlgData1DGraph.h"


// CDlgData1DGraph dialog

IMPLEMENT_DYNAMIC(CDlgData1DGraph, CDialog)

CDlgData1DGraph::CDlgData1DGraph(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgData1DGraph::IDD, pParent)
{

}

CDlgData1DGraph::~CDlgData1DGraph()
{
}

void CDlgData1DGraph::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgData1DGraph, CDialog)
END_MESSAGE_MAP()


// CDlgData1DGraph message handlers
