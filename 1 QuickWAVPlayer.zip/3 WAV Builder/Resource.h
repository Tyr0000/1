//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Builder.rc
//
#define IDD_BUILDER_DIALOG              103
#define IDR_MAINFRAME                   128
#define IDC_EDIT_SCRIPT_DIR             1000
#define IDC_EDIT_FILE                   1001
#define IDC_STATIC_SCRIPT_FILE					1002
#define IDC_STATIC_LEVEL_SCRIPT_FILE		1003
#define IDC_STATIC_LEVEL_BUILT_CNT      1004
#define IDC_BUTTON_BROWSE_DIR           1005
#define IDC_BUTTON_BROWSE_FILE          1006
#define IDC_BUTTON_BUILD                1007
#define IDC_LIST1                       1008
#define IDC_EDIT_SRC_DIR                1009
#define IDC_EDIT_E_DIR                  1010
#define IDC_EDIT_N_DIR                  1011
#define IDC_EDIT_RSLT_DIR               1012
#define IDC_COMBO_SRC_DIR_1             1013
#define IDC_COMBO_E_DIR_1               1014
#define IDC_COMBO_RSLT_DIR_1						1015
#define IDC_COMBO_SRC_DIR_2             1016
#define IDC_COMBO_E_DIR_2               1017
#define IDC_COMBO_RSLT_DIR_2						1018
#define IDC_COMBO_SRC_DIR_3             1019
#define IDC_COMBO_E_DIR_3               1020
#define IDC_COMBO_RSLT_DIR_3						1021
#define IDC_COMBO_SRC_DIR_4             1022
#define IDC_COMBO_E_DIR_4               1023
#define IDC_COMBO_RSLT_DIR_4					  1024
#define IDC_COMBO_SRC_DIR_M5            1025
#define IDC_COMBO_E_DIR_M5              1026 
#define IDC_COMBO_RSLT_DIR_M5           1027 
#define IDC_COMBO_SRC_DIR_F5            1028	
#define IDC_COMBO_E_DIR_F5              1029 
#define IDC_COMBO_RSLT_DIR_F5           1030 
#define IDC_BUTTON_BUILD1               1031 
#define IDC_BUTTON_BUILD2               1032 
#define IDC_BUTTON_BUILD3               1033 
#define IDC_BUTTON_BUILD4               1034  
#define IDC_BUTTON_BUILD5               1035  
#define IDC_BUTTON_BUILD_ALL            1036  
#define IDC_BUTTON_SELECT_ALL           1037  
#define IDC_BUTTON_UNSELECT_ALL         1038
#define IDC_BUTTON_STOP      						1039
#define IDC_BUTTON_STOP1                1040
#define IDC_BUTTON_STOP2                1041
#define IDC_BUTTON_STOP3                1042
#define IDC_BUTTON_STOP4                1043
#define IDC_BUTTON_STOP5			          1044
#define IDC_BUTTON_STOP_ALL							1045
									

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1050
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
