// PlayerDlg.cpp : implementation file
//

#define _BUILDER

#include "stdafx.h"
#include "math.h"
#include "Builder.h"
#include "BuilderDlg.h"

#include <vector>

#include "..\Utility\WavUtility.h"
#include "..\Utility\LogFile.h"
#include "..\Utility\mp3Utility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// void LoadLevelData(UINT CntrlId);
DWORD CALLBACK BuildLevelThrdProc(LPVOID Level);

typedef struct
{
	HANDLE hFile;
	char *pBuff;
	char *pData;
	int DataLen;
//	DWORD DataOffset;
	int Duration;
	int PauseBytesCnt0;
	int PauseBytesCnt1;
	TCHAR FN[32];
	char FNum[32];
//	char *pFN;
} WAV_MAP_DATA;

std::vector <WAV_MAP_DATA> SrcWavDataList, eWavDataList, nWavDataList;

typedef struct
{
//	TCHAR Dir[MAX_PATH+ 1];
//	TCHAR SrcDir0[MAX_PATH+ 1];
	int DirLen;
//	int SrcDirShortLen;
	TCHAR FN[MAX_PATH+ 1];
	std::vector <WAV_MAP_DATA> WavDataList;
} WAV_SRC_MAP_DATA, WAV_DIR_MAP_DATA;

#define MAX_LEVEL5_SUBDIR_CNT			2

// std::vector <WAV_SRC_MAP_DATA> SrcMultiWavDataList;
WAV_DIR_MAP_DATA SrcMultiWavDataList[5];
WAV_DIR_MAP_DATA eMultiWavDataList[5];
WAV_DIR_MAP_DATA eLevel1WavDataList, SrcLevel1WavDataList,
								 eLevel2WavDataList, SrcLevel2WavDataList,
								 eLevel3WavDataList, SrcLevel3WavDataList,
								 eLevel4WavDataList, SrcLevel4WavDataList,
								 eLevel5WavDataList[MAX_LEVEL5_SUBDIR_CNT], SrcLevel5WavDataList[MAX_LEVEL5_SUBDIR_CNT];

typedef struct
{
/*
	int CNTRL_ID_EM;
	int CNTRL_ID_SRCM;
	int CNTRL_ID_EF;
	int CNTRL_ID_SRCF;
*/
//	TCHAR *pRsltDir;
	WAV_DIR_MAP_DATA *pSrcLevelWavDataList;
	WAV_DIR_MAP_DATA *peLevelWavDataList;
} LEVEL_DATA;
/*
LEVEL_DATA LevelDataList[5]=
{
	{IDC_COMBO_E_DIR_M1, IDC_COMBO_SRC_DIR_M1, IDC_COMBO_E_DIR_F1, IDC_COMBO_SRC_DIR_F1, eLevelWavDataList1, SrcLevelWavDataList1},
	IDC_COMBO_E_DIR_M2, IDC_COMBO_SRC_DIR_M2, IDC_COMBO_E_DIR_F2, IDC_COMBO_SRC_DIR_F2, eLevelWavDataList2, SrcLevelWavDataList2,
	IDC_COMBO_E_DIR_M3, IDC_COMBO_SRC_DIR_M3, IDC_COMBO_E_DIR_F3, IDC_COMBO_SRC_DIR_F3, eLevelWavDataList3, SrcLevelWavDataList3,
	IDC_COMBO_E_DIR_M4, IDC_COMBO_SRC_DIR_M4, IDC_COMBO_E_DIR_F4, IDC_COMBO_SRC_DIR_F4, eLevelWavDataList4, SrcLevelWavDataList4,
	IDC_COMBO_E_DIR_M5, IDC_COMBO_SRC_DIR_M5, IDC_COMBO_E_DIR_F5, IDC_COMBO_SRC_DIR_F5, eLevelWavDataList5, SrcLevelWavDataList5
};
*/
LEVEL_DATA LevelDataList[5]=
{
	&SrcLevel1WavDataList, &eLevel1WavDataList, 
	&SrcLevel2WavDataList, &eLevel2WavDataList, 
	&SrcLevel3WavDataList, &eLevel3WavDataList, 
	&SrcLevel4WavDataList, &eLevel4WavDataList, 
	 SrcLevel5WavDataList,  eLevel5WavDataList
};

int ComboDirCnt[6][3];

typedef enum
{
	BS_UNDEFINED,
	BS_WRITE_SRC_DATA,
	BS_WRITE_E_DATA,
	BS_WRITE_N_DATA,
	BS_WRITE_WAV,
	BS_WRITE_BEEP,
	BS_WRITE_PAUSE,
	BS_WRITE_PAUSE_VAL
} BUILT_STATE;

WAVEFORMATEX BeepInfo;

int  DataPos, BeepDataLen, InitialLen, HdrLen, PauseBytesCnt; //ShortPauseBytesCnt;
char *pBeepBuff= NULL, *pBeepData, *pPauseData= NULL, *pFmtData;
DWORD *pTotalLenVal, *pDataLenVal;
DWORD SamplesPerSec= 0;

int BuildCnt= 0;
//HANDLE hMp3Mutex= NULL;
HANDLE hBuildMutex= NULL;
HANDLE hLevelThrds[5]= {0};
BOOL StopBuild= FALSE;
BOOL StopLevelBuild[5]= {FALSE};
BOOL LevelInBuild[5]= {FALSE};

typedef TCHAR FN[MAX_PATH+ 1];

TCHAR IniPath[MAX_PATH+ 1]; 
TCHAR WorkDir[MAX_PATH+ 1]; 
TCHAR DirPath[MAX_PATH +1];
TCHAR eDir[MAX_PATH+ 1]; 
TCHAR eDir1[MAX_PATH+ 1]; 
TCHAR nDir[MAX_PATH+ 1]; 
TCHAR SrcDir[MAX_PATH+ 1]; 
TCHAR RsltDir[MAX_PATH+ 1]; 
TCHAR RsltLevelDir[6][MAX_PATH+ 1]; 
TCHAR eDirPrev[MAX_PATH+ 1]; 
TCHAR nDirPrev[MAX_PATH+ 1]; 
TCHAR SrcDirPrev[MAX_PATH+ 1]; 
TCHAR ScriptDir[MAX_PATH+ 1]; 
TCHAR ScriptFN[MAX_PATH+ 1];
TCHAR SrcFN[MAX_PATH+ 1];
TCHAR eFN[MAX_PATH+ 1];
TCHAR nFN[MAX_PATH+ 1];
TCHAR RsltFN[MAX_PATH+ 1];
TCHAR BeepFN[MAX_PATH+ 1];

int ScriptDirLen;
int SrcDirLen;
int eDirLen;
int nDirLen;
int RsltDirLen;
int RsltLevelDirLen[6];

HANDLE hBuildThrd= NULL;
HANDLE hRsltFile= NULL;
//HANDLE hRsltFiles[5];

struct _GuiParams
{
	HWND hScriptInfoWnd;
	HWND hLevelScriptInfoWnd;
	HWND hBuildCntWnd;
	HWND hScriptListBoxWnd;
//	HWND hDirListBoxWnd;
//	HWND hDirComboBoxWnd;
	HWND hDlg;
} GUI_PARAMS, GuiParams; 

//FILE_LIST SrcFileList, eFileList, nFileList;

// CBuilderDlg dialog

CBuilderDlg::CBuilderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBuilderDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CBuilderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CBuilderDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON_BUILD, &CBuilderDlg::OnBnClickedButtonBuild)
	ON_EN_CHANGE(IDC_EDIT_SCRIPT_DIR, &CBuilderDlg::OnEnChangeEditScriptDir)
	ON_EN_CHANGE(IDC_EDIT_E_DIR, &CBuilderDlg::OnEnChangeEditEDir)
//	ON_EN_CHANGE(IDC_EDIT_E_DIR1, &CBuilderDlg::OnEnChangeEditEDir)
	ON_EN_CHANGE(IDC_EDIT_SRC_DIR, &CBuilderDlg::OnEnChangeEditSrcDir)
//	ON_EN_CHANGE(IDC_EDIT_SRC_DIR1, &CBuilderDlg::OnEnChangeEditSrcDir)
	ON_EN_CHANGE(IDC_EDIT_N_DIR, &CBuilderDlg::OnEnChangeEditNDir)
//	ON_CBN_EDITCHANGE(IDC_COMBO_DIR, &CBuilderDlg::OnCbnEditchangeCombo1)
// ON_CBN_SELCHANGE(IDC_COMBO_DIR, &CBuilderDlg::OnCbnEditchangeCombo1)
ON_BN_CLICKED(IDC_BUTTON_SELECT_ALL, &CBuilderDlg::OnBnClickedButtonSelectAll)
ON_BN_CLICKED(IDC_BUTTON_UNSELECT_ALL, &CBuilderDlg::OnBnClickedButtonUnselectAll)
ON_BN_CLICKED(IDC_BUTTON_STOP, &CBuilderDlg::OnBnClickedButtonStop)
ON_EN_CHANGE(IDC_EDIT_RSLT_DIR, &CBuilderDlg::OnEnChangeEditRsltDir)
END_MESSAGE_MAP()

//ON_CBN_SELCHANGE(IDC_COMBO_DIR, &CBuilderDlg::OnCbnSelchangeComboDir)

// CBuilderDlg message handlers

void LoadBeep()
{
	int i;

	if (pBeepBuff != NULL)
	{
		LocalFree(pBeepBuff);
		pBeepBuff= NULL;
	}
	i= LoadFileToBuff(BeepFN, &pBeepBuff);	
  if ((i == 0) || (i == INVALID_FILE_SIZE))
	{
		::MessageBox(::GetTopWindow(0), L"Unable to load beep.wav.\nCheck if this file exist in program directory", L"Input data error", MB_OK | MB_ICONERROR);\
		return;
	}
	if (*(DWORD *)pBeepBuff != 0x46464952)				// "RIFF"
	{
		::MessageBox(::GetTopWindow(0), L"beep.wav is wrong.\nCheck if this one is correct wav file", L"Input data error", MB_OK | MB_ICONERROR);\
		return;
	}
	i= 16+ *(DWORD *)&pBeepBuff[16];
	while (*(DWORD *)&pBeepBuff[i] != 0x61746164) // "data", skip additional header
		i++;

	pFmtData= pBeepBuff+ 0x10;
	pTotalLenVal= (DWORD *)&pBeepBuff[4];
	pDataLenVal= (DWORD *)&pBeepBuff[i+ 4];
	BeepDataLen= *pDataLenVal;
	InitialLen= *pTotalLenVal- BeepDataLen;
	HdrLen= i+ 8;
	pBeepData= pBeepBuff+ HdrLen;
  GetFormatInfo(pBeepBuff, &BeepInfo);
	PauseBytesCnt= BeepInfo.nAvgBytesPerSec; // >> 1;
	pPauseData= (char *)LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT, PauseBytesCnt);
	SamplesPerSec= BeepInfo.nSamplesPerSec;
}
/*
unsigned __int64 freq, begin, end;
float ReadTime= 0, WriteTime= 0, CalcTime= 0, DataTime= 0, Total, Start, End;
char InfoStr[128];
*/
BOOL CBuilderDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

//	::GetCurrentDirectory(MAX_PATH+ 1, WorkDir);

int i, j;
TCHAR Str0[32], Str1[32];

  InitLogFile();

//	QueryPerformanceFrequency((LARGE_INTEGER*)&freq);
  
	LoadLameLib();

	::GetCurrentDirectory(MAX_PATH+ 1, WorkDir);
	
	wcscpy(BeepFN, WorkDir);
	
	wcscat(BeepFN, L"\\beep.wav");
	LoadBeep();

	wcscpy(IniPath, WorkDir);
	wcscat(IniPath, L"\\Builder.ini");

//	SetDlgItemText(IDC_EDIT_FILE, RsltFN);

	GuiParams.hScriptInfoWnd= GetDlgItem(IDC_STATIC_SCRIPT_FILE)->m_hWnd;
	GuiParams.hLevelScriptInfoWnd= GetDlgItem(IDC_STATIC_LEVEL_SCRIPT_FILE)->m_hWnd;
	GuiParams.hBuildCntWnd= GetDlgItem(IDC_STATIC_LEVEL_BUILT_CNT)->m_hWnd;
	GuiParams.hScriptListBoxWnd= GetDlgItem(IDC_LIST1)->m_hWnd;
	GuiParams.hDlg= m_hWnd;

  for (i= 0; i <= 5; i++)
	{
		if (i == 5)
			wsprintf(Str0, L"LEVEL %i", i);
		else
			wsprintf(Str0, L"LEVEL %i", i+ 1);
		switch (i)
		{
			case 4:
  			j= GetPrivateProfileInt(Str0, L"SCnt_male", 0, IniPath);
			break;
			case 5:
  			j= GetPrivateProfileInt(Str0, L"SCnt_female", 0, IniPath);
			break;
			default:
				j= GetPrivateProfileInt(Str0, L"SCnt", 0, IniPath);
		}
		ComboDirCnt[i][0]= j;
		while (j > 0)
		{
			wsprintf(Str1, L"S%i", j);
			switch (i)
			{
				case 5:
					wcscat(Str1, L"_female");
				break;
				case 4:
					wcscat(Str1, L"_male");
				break;
			}
			if (::GetPrivateProfileString(Str0, Str1, NULL, SrcDir, MAX_PATH+ 1, IniPath) == 0)
				break;
			::SendMessage(GetDlgItem(IDC_COMBO_SRC_DIR_1+ i* 3)->m_hWnd, CB_ADDSTRING, 0, (WPARAM)SrcDir);
			j--;
		}
		switch (i)
		{
			case 4:
  			j= GetPrivateProfileInt(Str0, L"eCnt_male", 0, IniPath);
			break;
			case 5:
  			j= GetPrivateProfileInt(Str0, L"eCnt_female", 0, IniPath);
			break;
			default:
				j= GetPrivateProfileInt(Str0, L"eCnt", 0, IniPath);
		}
		ComboDirCnt[i][1]= j;
		while (j > 0)
		{
			wsprintf(Str1, L"e%i", j);
			switch (i)
			{
				case 5:
					wcscat(Str1, L"_female");
				break;
				case 4:
					wcscat(Str1, L"_male");
				break;
			}
			if (::GetPrivateProfileString(Str0, Str1, NULL, eDir, MAX_PATH+ 1, IniPath) == 0)
				break;
			::SendMessage(GetDlgItem(IDC_COMBO_E_DIR_1+ i* 3)->m_hWnd, CB_ADDSTRING, 0, (WPARAM)eDir);
			j--;
		}
		switch (i)
		{
			case 4:
  			j= GetPrivateProfileInt(Str0, L"RCnt_male", 0, IniPath);
			break;
			case 5:
  			j= GetPrivateProfileInt(Str0, L"RCnt_female", 0, IniPath);
			break;
			default:
				j= GetPrivateProfileInt(Str0, L"RCnt", 0, IniPath);
		}
		ComboDirCnt[i][2]= j;
		while (j > 0)
		{
			wsprintf(Str1, L"R%i", j);
			switch (i)
			{
				case 5:
					wcscat(Str1, L"_female");
				break;
				case 4:
					wcscat(Str1, L"_male");
				break;
			}
			if (::GetPrivateProfileString(Str0, Str1, NULL, RsltDir, MAX_PATH+ 1, IniPath) == 0)
				break;
			::SendMessage(GetDlgItem(IDC_COMBO_RSLT_DIR_1+ i* 3)->m_hWnd, CB_ADDSTRING, 0, (WPARAM)RsltDir);
			j--;
		}
	}
	eDir[0]= 0;
	nDir[0]= 0;
	SrcDir[0]= 0;
	eDirPrev[0]= 0;
	nDirPrev[0]= 0;
	SrcDirPrev[0]= 0;
	ScriptDir[0]= 0;
	ScriptFN[0]= '\\';
	ScriptFN[1]= 0;
	
 	::GetPrivateProfileString(L"DIRECTORIES", L"Script", NULL, ScriptDir, MAX_PATH+ 1, IniPath);
 	::GetPrivateProfileString(L"DIRECTORIES", L"Src",		 NULL, SrcDir,		MAX_PATH+ 1, IniPath);
 	::GetPrivateProfileString(L"DIRECTORIES", L"e",			 NULL, eDir,			MAX_PATH+ 1, IniPath);
 	::GetPrivateProfileString(L"DIRECTORIES", L"n",      L"",  nDir,			MAX_PATH+ 1, IniPath);
 	::GetPrivateProfileString(L"DIRECTORIES", L"Rslt",	 NULL, RsltDir,		MAX_PATH+ 1, IniPath);

	SetDlgItemText(IDC_EDIT_SCRIPT_DIR, ScriptDir);
	SetDlgItemText(IDC_EDIT_SRC_DIR, SrcDir);
	SetDlgItemText(IDC_EDIT_E_DIR, eDir);
	SetDlgItemText(IDC_EDIT_N_DIR, nDir);
	SetDlgItemText(IDC_EDIT_RSLT_DIR, RsltDir);

	hBuildMutex= ::CreateMutex(NULL, FALSE, NULL);
//	hMp3Mutex= ::CreateMutex(NULL, FALSE, NULL);

//	SetDlgItemText(IDC_EDIT_FROM1, L"1");
//	SetDlgItemText(IDC_EDIT_TO1, L"141");


//	SetDlgItemText(IDC_COMBO_DIR, L"You can type/copy here as well as select from drop list"); 
//	SetDlgItemText(IDC_COMBO_DIR, L"F:\\Src\\Quick Wav Tools\\Data 15 French Lesson"); 

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CBuilderDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CBuilderDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

#define CLEAR_WAV_DATA_LIST(WavDataList)\
	if (!WavDataList.empty())\
	{\
		for (pWavItem= WavDataList.begin(); pWavItem != WavDataList.end(); pWavItem++)\
		{\
			UnmapViewOfFile(pWavItem->pBuff);\
			CloseHandle(pWavItem->hFile);\
		}\
		WavDataList.clear();\
	}

void CBuilderDlg::OnDestroy()
{
	std::vector<WAV_MAP_DATA>::iterator pWavItem;

	CDialog::OnDestroy();

  if (hBuildThrd != NULL) 
	{
		if (WaitForSingleObject(hBuildThrd, 0) != WAIT_OBJECT_0)
		{
			TerminateThread(hBuildThrd, 0);
			CloseHandle(hRsltFile);
		}
		CloseHandle(hBuildThrd);
	}

//	SrcFileList.ClearFileList();
//	eFileList.ClearFileList();
//	nFileList.ClearFileList();	

	CLEAR_WAV_DATA_LIST(SrcWavDataList)
	CLEAR_WAV_DATA_LIST(eWavDataList)
	CLEAR_WAV_DATA_LIST(nWavDataList)

	LocalFree(pPauseData);
	LocalFree(pBeepBuff);

	::WritePrivateProfileString(L"DIRECTORIES", L"Script", ScriptDir, IniPath);
 	::WritePrivateProfileString(L"DIRECTORIES", L"Src",		 SrcDir,		IniPath);
 	::WritePrivateProfileString(L"DIRECTORIES", L"e",			 eDir,			IniPath);
 	::WritePrivateProfileString(L"DIRECTORIES", L"n",			 nDir,			IniPath);
 	::WritePrivateProfileString(L"DIRECTORIES", L"Rslt",	 RsltDir,		IniPath);

	CloseLogFile();

	::CloseHandle(hBuildMutex);
//	::CloseHandle(hMp3Mutex);
}

BOOL CBuilderDlg::PreTranslateMessage(MSG* pMsg)
{
	int i;

	switch (pMsg->message)
	{
 		case WM_KEYDOWN:
 			switch (pMsg->wParam)
			{
				case VK_ESCAPE:
					return 1;
				case VK_RETURN:
//				case VK_SPACE:
  					return 1;	
			}
		break;
		case WM_KEYUP:
				case VK_ESCAPE:
				case VK_RETURN:
				case VK_SPACE:
					return 1;
		break;
/*
//		case WM_RBUTTONDOWN:
		case WM_RBUTTONUP:
			if (::GetParent(pMsg->hwnd) != m_hWnd)
			::SendMessage(::GetParent(pMsg->hwnd), WM_SETTEXT, 0, NULL);
		return 1;
*/	}

	return CDialog::PreTranslateMessage(pMsg);
}


LRESULT CBuilderDlg::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	char Str[128];
	TCHAR Str0[32], Str1[32];
	WORD CntrlId;
	int i, j, l, Level;
  TCHAR Dir[MAX_PATH+ 1], *pDirStr;
	int DirLen, *pDirLen= NULL;
	WAV_DIR_MAP_DATA *pWavDirDataList;
	std::vector<WAV_MAP_DATA>::iterator pWavItem;
	BOOL ByEdit= FALSE;

	switch(message)
	{
		case WM_HOTKEY:
			MessageBeep(0);
			return 0;
		case WM_COMMAND:
			CntrlId= LOWORD(wParam);
			Dir[0]= 0; 
			if ((CntrlId >= IDC_COMBO_SRC_DIR_1) && (CntrlId <= IDC_COMBO_RSLT_DIR_F5))
			{
				if ((HIWORD(wParam) != CBN_EDITCHANGE) && (HIWORD(wParam) != CBN_SELCHANGE))
					return 1;

				i= 17- (IDC_COMBO_RSLT_DIR_F5- CntrlId);
				Level= i / 3;
				i= i % 3;
				switch (i)
				{
					case 0:
						if (Level < 5)
						{
//							pWavDirDataList= LevelDataList[Level].pSrcLevelWavDataList;
							pDirStr= LevelDataList[Level].pSrcLevelWavDataList->FN;
							pDirLen= &LevelDataList[Level].pSrcLevelWavDataList->DirLen;
						}
						else
						{
//							pWavDirDataList= &SrcLevel5WavDataList[1]; 
							pDirStr= SrcLevel5WavDataList[1].FN;
							pDirLen= &SrcLevel5WavDataList[1].DirLen;
						}
					break;			 
					case 1:
						if (Level < 5)
						{
//							pWavDirDataList= LevelDataList[Level].peLevelWavDataList;
							pDirStr= LevelDataList[Level].peLevelWavDataList->FN;
							pDirLen= &LevelDataList[Level].peLevelWavDataList->DirLen;
						}
						else
						{
//							pWavDirDataList= &eLevel5WavDataList[1]; 
							pDirStr= eLevel5WavDataList[1].FN;
							pDirLen= &eLevel5WavDataList[1].DirLen;
						}
					break;			 
					case 2:
//						pWavDirDataList= NULL;
						pDirStr= RsltLevelDir[Level];
						pDirLen= &RsltLevelDirLen[Level];
					break;
				}

				switch (HIWORD(wParam))
				{
					case CBN_EDITCHANGE: 
						ByEdit= TRUE;
						DirLen= GetDlgItemText(CntrlId, Dir, MAX_PATH+ 1);
						l= ::GetFileAttributes(Dir);
						if (l == INVALID_FILE_ATTRIBUTES)
						{
							pDirStr[0]= 0;
							return 1;
						}
						l&= FILE_ATTRIBUTE_DIRECTORY;
						if (l == 0)
						{
							pDirStr[0]= 0;
							return 1;
						}

						j= ::SendMessage((HWND)lParam, CB_FINDSTRINGEXACT, 0, (LPARAM)Dir);
						if (j== -1)
						{
							j= ::SendMessage((HWND)lParam, CB_ADDSTRING, 0, (LPARAM)Dir);
							if (j != -1)
							{								
								switch (i)
								{
									case 0:
										wsprintf(Str1, L"SCnt", ComboDirCnt[Level][i]);
									break;
									case 1:
										wsprintf(Str1, L"eCnt", ComboDirCnt[Level][i]);
									break;
									case 2:
										wsprintf(Str1, L"RCnt", ComboDirCnt[Level][i]);
									break;
								}
								switch (Level)
								{
									case 5:
										wsprintf(Str0, L"LEVEL %i", Level);
										wcscat(Str1, L"_female");
									break;
									case 4:
										wcscat(Str1, L"_male");
//										wsprintf(Str0, L"LEVEL %i", Level+ 1);
									default:
										wsprintf(Str0, L"LEVEL %i", Level+ 1);
								}
								ComboDirCnt[Level][i]++;
								wsprintf((TCHAR *)Str, L"%i", ComboDirCnt[Level][i]);
								if (!WritePrivateProfileString(Str0, Str1, (TCHAR *)Str, IniPath))
										ComboDirCnt[Level][i]--;
								else
								{
									switch (i)
									{
										case 0:
											wsprintf(Str1, L"S%i", ComboDirCnt[Level][i]);
										break;
										case 1:
											wsprintf(Str1, L"e%i", ComboDirCnt[Level][i]);
										break;
										case 2:
											wsprintf(Str1, L"R%i", ComboDirCnt[Level][i]);
										break;
									}
									switch (Level)
									{
										case 5:
											wcscat(Str1, L"_female");
										break;
										case 4:
											wcscat(Str1, L"_male");
									}
									WritePrivateProfileString(Str0, Str1, Dir, IniPath);
								}
							}
						}
					case CBN_SELCHANGE:
						if (!ByEdit)
						{
							j= ::SendMessage((HWND)lParam, CB_GETCURSEL, 0, 0);
							DirLen= ::SendMessage((HWND)lParam, CB_GETLBTEXT, j, (LPARAM)Dir);
						}
						wcscpy(pDirStr, Dir);
						*pDirLen= DirLen;
						if (Dir[DirLen- 1] != '\\')
						{
							pDirStr[DirLen]= '\\';
							pDirStr[DirLen+ 1]= 0;
							*pDirLen= DirLen+ 1;
						}
					break;			
					default:
						return 1;
				}
			}
			else
				if ((CntrlId >= IDC_BUTTON_BUILD1) && (CntrlId <= IDC_BUTTON_BUILD_ALL))
				{
					if (BuildCnt == 0)
					{
						LoadBeep();

						wcscpy(ScriptFN, ScriptDir);
						ScriptDirLen= wcslen(ScriptDir);
						SrcDirLen= wcslen(SrcDir);
						eDirLen= wcslen(eDir);
						nDirLen= wcslen(nDir);

						if (ScriptFN[SrcDirLen- 1] != '\\')
						{
							ScriptFN[ScriptDirLen]= '\\';
							ScriptFN[ScriptDirLen+ 1]= 0;
							ScriptDirLen++;
						}
						if (wcscmp(nDirPrev, nDir) != 0)
						{
							wcscpy(nDirPrev, nDir);
							wcscpy(nFN, nDir);
							CLEAR_WAV_DATA_LIST(nWavDataList)
						}
						if (nFN[eDirLen- 1] != '\\')
						{
							nFN[nDirLen]= '\\';
							nFN[nDirLen+ 1]= 0;
							nDirLen++;
						}
					}
					if (HIWORD(wParam) == BN_CLICKED)
					{
						i= IDC_BUTTON_BUILD_ALL- CntrlId;
						i= 5- i;
						if (i < 5)
							j= i;
						else
						{
							j= 0;
//							i= 5;
						}
						do
						{
							if (((j < 4) && ((LevelDataList[j].peLevelWavDataList->FN[0] != 0) && (LevelDataList[j].pSrcLevelWavDataList->FN[0] != 0))) ||
								 (((j == 4) && (((SrcLevel5WavDataList[0].FN[0] != 0) && (eLevel5WavDataList[0].FN[0] != 0)) || ((SrcLevel5WavDataList[1].FN[0] != 0) && (eLevel5WavDataList[1].FN[0] != 0))))))
							{
								if (hLevelThrds[j] == NULL)
								{
									::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_BUILD1+ j), FALSE);
									::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_STOP1+ j), TRUE);
									hLevelThrds[j]= CreateThread(NULL, 0, BuildLevelThrdProc, (LPVOID)(j), 0, NULL);
									BuildCnt++;
								}
							}
NEXT_LEVEL:						
							j++;
						}
						while (j < i);
						if (BuildCnt == 0)
						{
							::MessageBox(m_hWnd, L"One of src/E directories either is empty or not valid", L"User error", MB_OK);
							return 0;
						}
						if (i == 5)
							::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_BUILD_ALL), FALSE);
						if (BuildCnt > 1)
							::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_STOP_ALL), TRUE);
						itoa(BuildCnt, Str, 10);
						SetDlgItemTextA(m_hWnd, IDC_STATIC_LEVEL_BUILT_CNT, Str);
					}
				}
				else
					if ((CntrlId >= IDC_BUTTON_STOP1) && (CntrlId <= IDC_BUTTON_STOP_ALL))
					{
						if (HIWORD(wParam) == BN_CLICKED)
						{
							i= IDC_BUTTON_STOP5- CntrlId;
							i= 4- i;
							if (i < 5)
								j= i;
							else
							{
								j= 0;
								i= 5;
							}
							do
							{					
								if (hLevelThrds[j] != NULL)
								if (LevelInBuild[j])
								{
									StopLevelBuild[j]= TRUE;
								}
								else
								{
									TerminateThread(hLevelThrds[j], 0);
									::SendMessage(m_hWnd, WM_LEVEL_BUILD_DONE, 0, j);
								}
								::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_STOP1+ j), FALSE);
								j++;
							}
							while (j < i);
							if (i == 5)
								::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_STOP_ALL), FALSE);
						}
					}
			return 1;
		
		case WM_REFRESH_INFO:
			if (wParam == -1)
//				::SetDlgItemText(m_hWnd, IDC_STATIC_CURRENT_SCRIPT_FILE, (LPCTSTR)lParam);
				::SendMessage(GuiParams.hScriptInfoWnd, WM_SETTEXT, 0, lParam);
			else
				::SendMessage(GuiParams.hScriptListBoxWnd, LB_SETSEL, 0, wParam); 
			return 0;

		case WM_BUILD_DONE:
			CloseHandle(hBuildThrd);
			hBuildThrd= NULL;
			GetDlgItem(IDC_BUTTON_BUILD)->EnableWindow(TRUE);
			GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(FALSE);
			::sndPlaySound(BeepFN, SND_ASYNC); 
//			::SetDlgItemText(m_hWnd, IDC_STATIC_CURRENT_SCRIPT_FILE, NULL);
			::SendMessage(GuiParams.hScriptInfoWnd, WM_SETTEXT, 0, NULL);

			if (wParam != 0)
				::MessageBox(m_hWnd, L"Buiding process was done with error.\nFor detailed information see log file", L"Error", MB_ICONERROR | MB_OK);
			return 0;
		
		case WM_LEVEL_REFRESH_INFO:
//				::SetDlgItemText(m_hWnd, IDC_STATIC_CURRENT_SCRIPT_FILE, &ScriptFN[ScriptDirLen]);
			::SendMessage(GuiParams.hLevelScriptInfoWnd, WM_SETTEXT, 0, lParam);
			return 0;

		case WM_LEVEL_BUILD_DONE:
			BuildCnt--;
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_BUILD1+ lParam), TRUE);
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_STOP1+ lParam), FALSE);
			CloseHandle(hLevelThrds[lParam]);
			hLevelThrds[lParam]= NULL;
			itoa(BuildCnt, Str, 10);
//			SetDlgItemTextA(m_hWnd, IDC_STATIC_LEVEL_BUILT_CNT, Str);
			::SendMessageA(GuiParams.hBuildCntWnd, WM_SETTEXT, 0, (LPARAM)Str);
			if (BuildCnt != 0)
				return 0;
			::sndPlaySound(BeepFN, SND_ASYNC); 
			if (wParam != 0)
				::MessageBox(m_hWnd, L"Buiding process was done with error.\nFor detailed information see log file", L"Error", MB_ICONERROR | MB_OK);
			::SendMessage(GuiParams.hLevelScriptInfoWnd, WM_SETTEXT, 0, NULL);
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_BUILD_ALL), TRUE);
			::EnableWindow(::GetDlgItem(m_hWnd, IDC_BUTTON_STOP_ALL), FALSE);

//ReadTime= 0;
//WriteTime= 0;
//CalcTime= 0;


			return 0;
	}

	return CDialog::DefWindowProc(message, wParam, lParam);
}

TCHAR *GetShortFN(TCHAR *pFN, int Len)
{
	int i;

	i= Len;
	while (i > 0)
	{
		i--;
		if (pFN[i] == '\\')
			return (pFN+ i+ i);
	}
	return pFN;
}

#define LOG_INFO\
	LogMsg("\n***** Script: %ws", &ScriptFN[ScriptDirLen]);

// LogMsg("%ws", RsltFN);

#define ERR_MSG_BREAK(Descr)\
	IsErr= TRUE;\
	ErrCnt++;\
	LOG_INFO\
	LogMsg("LineNumber: %i", LineCnt);\
	LogMsg(Descr);\
	break;

#define ERR_LOG_BREAK(FunctDescr)\
	IsErr= TRUE;\
	ErrCnt++;\
	LOG_INFO\
	LogMsg("LineNumber: %i", LineCnt);\
	LogErr(FunctDescr);\
	break;

#define GO_TO_NEXT_SYM (Step)\
	i+= Step;\
	pStr+= Step;

#define GO_TO_NEXT_LINE\
	if (*(WORD *)pStr == 0x0A0D)\
	{\
		*(WORD *)pStr= 0;\
		i+= 2;\
		pStr+= 2;\
		LineCnt++;\
	}\
	else\
	{\
	  if ((i >= ScriptLen) || (*pStr == 0))\
			EofScript= TRUE;\
		else\
		{\
			pValStr= NULL;\
			ERR_MSG_BREAK("Either wrong number or no CRLF")\
		}\
	}

// (*(WORD *)pStr == 0x0D0A) || 

#define GET_VAL\
	pValStr= pStr;\
  Cnt= 0;\
	while ((*pStr >= '0') && (*pStr <= '9'))\
	{\
		pStr++;\
		i++;\
		Cnt++;\
	}\
	GO_TO_NEXT_LINE

#define FIND_WAV_DATA(WavDataList)\
	ToWriteCnt= 0;\
  pWriteData= NULL;\
	if (!WavDataList.empty())\
	{\
		for (pWavItem= WavDataList.begin(); pWavItem != WavDataList.end(); pWavItem++)\
		{\
			if (strcmp(pWavItem->FNum, pValStr) == NULL)\
			{\
				ToWriteCnt= pWavItem->DataLen;\
				pWriteData= pWavItem->pData;\
				PauseBytesCnt0= pWavItem->PauseBytesCnt0;\
				PauseBytesCnt1= pWavItem->PauseBytesCnt1;\
				break;\
			}\
		}\
	}

#define LOAD_WAV_DATA(Dir)\
					if (pWriteData == NULL)\
					{\
						for (j= 0; j <= Cnt; j++)\
						{\
							Dir##FN[Dir##DirLen+ j]= (TCHAR)pValStr[j];\
							WavData.FNum[j]= pValStr[j];\
						}\
						Dir##FN[Dir##DirLen+ Cnt]= '.';\
						Dir##FN[Dir##DirLen+ Cnt+ 1]= 'w';\
						Dir##FN[Dir##DirLen+ Cnt+ 2]= 'a';\
						Dir##FN[Dir##DirLen+ Cnt+ 3]= 'v';\
						Dir##FN[Dir##DirLen+ Cnt+ 4]= 0;\
						hFile= CreateFile(Dir##FN, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);\
						if (hFile == INVALID_HANDLE_VALUE)\
						{\
							LogMsg(#Dir": %s.wav", pValStr);\
							LogMsg("%ws", Dir##FN);\
							ERR_LOG_BREAK("CreateFile")\
						}\
						FileSize= GetFileSize(hFile, (DWORD *)&BytesCnt);\
						WavData.hFile= CreateFileMapping(hFile, NULL, PAGE_READONLY, 0, 0, NULL);\
						if (WavData.hFile == NULL)\
						{\
							CloseHandle(hFile);\
							LogMsg(#Dir"- %s", pValStr);\
							ERR_LOG_BREAK("CreateFileMapping")\
						}\
						WavData.pBuff= (char *)MapViewOfFile(WavData.hFile, FILE_MAP_READ, 0, 0, FileSize);\
						if (WavData.pBuff == NULL)\
						{\
							CloseHandle(hFile);\
							LogMsg(#Dir"- %s", pValStr);\
							ERR_LOG_BREAK("MapViewOfFile")\
						}\
						CloseHandle(hFile);\
						if (*(DWORD *)WavData.pBuff != 0x46464952)\
						{\
							LogMsg(#Dir"- %s", pValStr);\
							ERR_MSG_BREAK("not RIFF")\
						}\
						GetFormatInfo(WavData.pBuff, &CurrFormat);\
						if (SamplesPerSec == 0)\
						{\
							SamplesPerSec= CurrFormat.nSamplesPerSec;\
						}\
						else\
						{\
							if (SamplesPerSec != CurrFormat.nSamplesPerSec)\
							{\
								::MessageBox(::GetTopWindow(0), L"Sample rate (frequence) of files is not same.", L"Input data error", MB_OK | MB_ICONERROR);\
								LogMsg(#Dir"- %s", pValStr);\
								ERR_MSG_BREAK("SamplesPerSec is not same")\
							}\
						}\
						if (!IsFormatMonoSign16pcm(&CurrFormat))\
						{\
							::MessageBox(::GetTopWindow(0), L"Unsupported format.", L"Input data error", MB_OK | MB_ICONERROR);\
							LogMsg(#Dir"- %s", pValStr);\
							ERR_MSG_BREAK("not MonoSign16pcm")\
						}\
						DataInd= GetSampleBuff(WavData.pBuff, &WavData.DataLen);\
						WavData.pData= WavData.pBuff+ DataInd;\
						WavData.Duration= WavData.DataLen/ CurrFormat.nAvgBytesPerSec;\
						if (WavData.DataLen < PauseBytesCnt)\
						{\
							WavData.PauseBytesCnt0= 0;\
							WavData.PauseBytesCnt1= WavData.DataLen;\
						}\
						else\
						{\
							WavData.PauseBytesCnt0= WavData.DataLen/ PauseBytesCnt;\
							WavData.PauseBytesCnt1= WavData.DataLen % PauseBytesCnt;\
							if ((PauseBytesCnt1 & 1) != 0)\
								PauseBytesCnt1++;\
						}\
						WavData.PauseBytesCnt0+= 2;\
						Dir##WavDataList.push_back(WavData);\
						pWriteData= WavData.pData;\
						ToWriteCnt= WavData.DataLen;\
						PauseBytesCnt0= WavData.PauseBytesCnt0;\
						PauseBytesCnt1= WavData.PauseBytesCnt1;\
					}

//						memcpy(WavData.FNum, pValStr;\

DWORD CALLBACK BuildThrdProc(LPVOID lParam)
{
	WAVEFORMATEX CurrFormat;
	int DataInd;
  char *pData;
  int i, j, LineCnt, Cnt;
	DWORD BytesCnt;
	DWORD ToWriteCnt;
//  FILE_ENTRY *pFileEntry;
	int FileSize, ScriptLen, DataLen, FileCnt= 0;
//	char *pWaveBuff= NULL;
	char *pScriptBuff= NULL;
	char *pStr, *pValStr;
	BOOL Continue= FALSE, EofScript;
	BOOL IsErr= FALSE;
	static int SamplePerSec= 0;
	int ErrCnt= 0;
//	char ErrDescr[1024];
	std::vector<WAV_MAP_DATA>::iterator pWavItem;
	WAV_MAP_DATA *pWavData, WavData;
//	int PauseByteCnt;
	HANDLE hFile;
	BUILT_STATE State= BS_UNDEFINED;
	char *pWriteData;
	int PauseBytesCnt0, PauseBytesCnt1;
	double PauseDuration;
	int ScriptList[25];
	int ScriptCnt= 0, ScriptInd= 0, From, To;

	if (lParam != 0)
	{
		From= 1;
		To= 141;
		ScriptCnt= 141;
	}
	else
		ScriptCnt= 0;

	if (ScriptCnt == 0)
	{
		ScriptCnt= ::SendMessage(GuiParams.hScriptListBoxWnd, LB_GETSELCOUNT, 0, 0);
		if ((ScriptCnt == LB_ERR) || (ScriptCnt == 0))
		{
			SendMessage(GuiParams.hDlg, WM_BUILD_DONE, 0, 0);
			::MessageBox(GuiParams.hDlg, L"Select a script from the list to process", L"User error", MB_OK);
			return 0;
		}
		ScriptCnt= ::SendMessage(GuiParams.hScriptListBoxWnd, LB_GETSELITEMS, 25, (LPARAM)ScriptList);
		if ((ScriptCnt == LB_ERR) || (ScriptCnt == 0))
		{
			SendMessage(GuiParams.hDlg, WM_BUILD_DONE, 0, 0);
			::MessageBox(GuiParams.hDlg, L"Select a script from the list to process", L"User error", MB_OK);
			return 0;
		}
	}

	do
	{
		IsErr= FALSE;
		if (lParam == 0)
		{
			i= ::SendMessage(GuiParams.hScriptListBoxWnd, LB_GETTEXT, ScriptList[ScriptInd], (LPARAM)&ScriptFN[ScriptDirLen]);
			if (i == 0)
			{
				IsErr= TRUE;
				ErrCnt++;
				LogMsg("***** Impossibly to get script file name: %i", ScriptInd);
				goto FINALIZE;
			}
		}
		else
//			itoa(ScriptInd+1, &ScriptFN[ScriptDirLen], 10);
			wsprintf(&ScriptFN[ScriptDirLen], L"%i.txt", ScriptInd+1);

		DataLen= 0;
    
		wcscpy(&RsltFN[RsltDirLen], &ScriptFN[ScriptDirLen]);
		i= wcslen(RsltFN);
		RsltFN[i- 3]= 'w';
		RsltFN[i- 2]= 'a';
		RsltFN[i- 1]= 'v';

//	SetWindowText(GuiParams.hScriptInfoWnd, pFileEntry->FN);

		SendMessage(GuiParams.hDlg, WM_REFRESH_INFO, -1, (LPARAM)&ScriptFN[ScriptDirLen]); 

		hRsltFile= CreateFile(RsltFN, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL); 
		if (hRsltFile == INVALID_HANDLE_VALUE)
		{
//			::MessageBox(::GetTopWindow(0), L"Impossibly to create a target file.", L"Error", MB_OK | MB_ICONERROR);
//			SendMessage(GuiParams.hDlg, WM_BUILD_DONE, 0, 0);
			IsErr= TRUE;
			ErrCnt++;
			LOG_INFO
			LogErr("Impossibly to create a target file. CreateFile");
			goto FINALIZE;
//			ERR_LOG_BREAK("CreateFile")
//			return INVALID_FILE_SIZE;
		}
		
		if (SetFilePointer(hRsltFile, HdrLen, NULL, FILE_BEGIN) != HdrLen)
		{
			IsErr= TRUE;
			ErrCnt++;
			LOG_INFO
			LogErr("SetFilePointer");
			goto FINALIZE;
		}
    if (!SetEndOfFile(hRsltFile))
		{
			IsErr= TRUE;
			ErrCnt++;
			LOG_INFO
			LogErr("SetEndOfFile");
			goto FINALIZE;
		}

		ScriptLen= LoadFileToBuff(ScriptFN, &pScriptBuff);
		if (ScriptLen == INVALID_FILE_SIZE)
		{
			IsErr= TRUE;
			ErrCnt++;
//			LOG_INFO
			LogMsg("Impossibly to load script");
			goto FINALIZE;
//			ERR_BREAK("Impossibly to load script")
		}
		IsErr= FALSE;
		pStr= pScriptBuff;
		pStr[ScriptLen]= 0;
		EofScript= FALSE;
		i= 0;
		LineCnt= 0;
		do
		{
// QueryPerformanceCounter((LARGE_INTEGER*)&begin);

			State= BS_UNDEFINED;
			pWriteData= NULL;
			switch (*pStr)
			{
				case '<':
					do
					{
						pStr++;
						i++;
					}
					while (*pStr != 0x0D);
					GO_TO_NEXT_LINE
				break;
	
				case 'E':
					if (*(pStr+ 1) != '-')
					{
						ERR_MSG_BREAK("no '-' after E")
					}
					pStr+= 2;
					i+= 2;
					GET_VAL
					FIND_WAV_DATA(eWavDataList)
					LOAD_WAV_DATA(e)
					State= BS_WRITE_WAV;
				break;
				
				case 'n':
					if (*(pStr+ 1) != '-')
					{
						ERR_MSG_BREAK("no '-' after n")
					}
					pStr+= 2; 
					i+= 2; 
					GET_VAL
					FIND_WAV_DATA(nWavDataList)
					LOAD_WAV_DATA(n)
					State= BS_WRITE_WAV;
				break;
				
				case 'p':
					if (*(pStr+ 1) == '#')
					{
						pStr+= 2; 
						i+= 2;
						GET_VAL
						FIND_WAV_DATA(SrcWavDataList)
						LOAD_WAV_DATA(Src)
					}
					else
					{
						pStr++;
						i++;
						PauseBytesCnt0= 0;
						PauseBytesCnt1= 0;
						pValStr= pStr;
						Cnt= 0;
						do
						{
							Cnt++;
							pStr++;
							i++;
						}
						while (((*pStr >= '0') && (*pStr <= '9')) || (*pStr == '.'));
						GO_TO_NEXT_LINE
						PauseDuration= atof(pValStr);
						PauseBytesCnt1= PauseBytesCnt* PauseDuration;
						if ((PauseBytesCnt1 & 1) != 0)
							PauseBytesCnt1++;
						if (PauseDuration > 1)
						{
							PauseBytesCnt0= PauseBytesCnt1/ PauseBytesCnt;
							PauseBytesCnt1= PauseBytesCnt1 % PauseBytesCnt;
						}
					}
					State= BS_WRITE_PAUSE_VAL;
				break;
				case 'B':
				case 'b':
					if (*(DWORD *)pStr == 0x50454542)   // beep
					{
						pStr+= 4; 
						i+= 4; 
						GO_TO_NEXT_LINE
						State= BS_WRITE_BEEP;
					}
				break;

				case 0x0D:
				case 0x0A:
					i++;
					EofScript= TRUE;;
				break;
				
				default:
					if ((*pStr < '0') || (*pStr > '9'))
					{
						IsErr= TRUE;
						ErrCnt++;
						ERR_MSG_BREAK("Wrong symbol.")
					}
					else
					{
						GET_VAL
						FIND_WAV_DATA(SrcWavDataList)
						LOAD_WAV_DATA(Src)
						State= BS_WRITE_WAV;
					}
			}
      if (StopBuild)
				break;
			BytesCnt= 0;
			switch (State)
			{
				case BS_WRITE_WAV:
					if (!WriteFile(hRsltFile, pWriteData, ToWriteCnt, &BytesCnt, NULL) || (ToWriteCnt != BytesCnt))
					{
						ERR_LOG_BREAK("WriteFile: Data")
					}
					DataLen+= ToWriteCnt;
				break;
				
				case BS_WRITE_BEEP:
					if (!WriteFile(hRsltFile, pBeepData, BeepDataLen, &BytesCnt, NULL) || (BeepDataLen != BytesCnt))
					{
						ERR_LOG_BREAK("WriteFile: Beep")
					}
					DataLen+= BeepDataLen;
				break;

				case BS_WRITE_PAUSE_VAL:
					while (PauseBytesCnt0 > 0)
					{
						if (!WriteFile(hRsltFile, pPauseData, PauseBytesCnt, &BytesCnt, NULL) || (PauseBytesCnt != BytesCnt))
						{
//							::MessageBox(::GetTopWindow(0), L"Impossibly to write into a target file.", L"Error", MB_OK | MB_ICONERROR);
//							LogErr("WriteFile");
							ERR_LOG_BREAK("WriteFile:PauseData0")
						}
						PauseBytesCnt0--;
						DataLen+= PauseBytesCnt;
					}
					if (PauseBytesCnt1 > 0)
					{
						if (!WriteFile(hRsltFile, pPauseData, PauseBytesCnt1, &BytesCnt, NULL) || (PauseBytesCnt1 != BytesCnt))
						{
//							::MessageBox(::GetTopWindow(0), L"Impossibly to write into a target file.", L"Error", MB_OK | MB_ICONERROR);
//							LogErr("WriteFile");
							ERR_LOG_BREAK("WriteFile:PauseData1")
						}
						DataLen+= PauseBytesCnt1;
					}
				break;
			}

// QueryPerformanceCounter((LARGE_INTEGER*)&end);
// DataTime+= ((float)(end-begin))/freq;

		}
		while ((i < ScriptLen) && (!IsErr) && (!EofScript) && (!StopBuild));

		if ((!IsErr) && (!StopBuild))
		{
			if (SetFilePointer(hRsltFile, 0, NULL, FILE_BEGIN) != 0)
			{
				IsErr= TRUE;
				ErrCnt++;
				LogErr("SetFilePointer: FILE_BEGIN");
//				ERR_BREAK("Impossibly to finalize a target file")
			}
			else
			{
				*pTotalLenVal= InitialLen+ DataLen;
				*pDataLenVal= DataLen;
				if (!WriteFile(hRsltFile, pBeepBuff, HdrLen, &BytesCnt, NULL) || (HdrLen != BytesCnt))
				{
//			::MessageBox(::GetTopWindow(0), L"Impossibly to finalize a target file.\Error code:#0002", L"Error", MB_OK | MB_ICONERROR);
					IsErr= TRUE;
					ErrCnt++;
					LogErr("WriteFile: wav header");
//				ERR_BREAK("Impossibly to finalize a target file")
				}
			}
		}

FINALIZE:
		if ((hRsltFile != NULL) && (!StopBuild))
		{
			::FlushFileBuffers(hRsltFile);
			CloseHandle(hRsltFile);
		}
		if (!IsErr)
			SendMessage(GuiParams.hDlg, WM_REFRESH_INFO, ScriptList[ScriptInd], 0);
		ScriptInd++;
	}
	while ((ScriptInd < ScriptCnt) && (!StopBuild));
 	
	LocalFree(pScriptBuff);
	pScriptBuff= NULL;


	StopBuild= FALSE;
	SendMessage(GuiParams.hDlg, WM_BUILD_DONE, ErrCnt, 0);
	return 0;
}

void CBuilderDlg::OnBnClickedButtonBuild()
{
//	char Str[32];
	int i;
	CWaitCursor WaitCursor;
	std::vector<WAV_MAP_DATA>::iterator pWavItem;

	if ((SrcDir[0] == 0) || (eDir[0] == 0) || (nDir[0] == 0) || (RsltDir[0] == 0))
	{
		::MessageBox(m_hWnd, L"One of directories is not exist or emty.\nCheck the directory pathes", L"User error", MB_OK);
		return;
	}

	LoadBeep();

	wcscpy(ScriptFN, ScriptDir);

	if (wcscmp(SrcDirPrev, SrcDir) != 0)
	{
		wcscpy(SrcDirPrev, SrcDir);
		wcscpy(SrcFN, SrcDir);
		CLEAR_WAV_DATA_LIST(SrcWavDataList)
	}
	if (wcscmp(eDirPrev, eDir) != 0)
	{
		wcscpy(eDirPrev, eDir);
		wcscpy(eFN, eDir);
		CLEAR_WAV_DATA_LIST(eWavDataList)
	}
	if (wcscmp(nDirPrev, nDir) != 0)
	{
		wcscpy(nDirPrev, nDir);
		wcscpy(nFN, nDir);
		CLEAR_WAV_DATA_LIST(nWavDataList)
	}

	ScriptDirLen= wcslen(ScriptDir);
	SrcDirLen= wcslen(SrcDir);
	eDirLen= wcslen(eDir);
	nDirLen= wcslen(nDir);
	RsltDirLen= wcslen(RsltDir);

	if (ScriptFN[SrcDirLen- 1] != '\\')
	{
		ScriptFN[ScriptDirLen]= '\\';
		ScriptFN[ScriptDirLen+ 1]= 0;
		ScriptDirLen++;
	}

	if (SrcFN[SrcDirLen- 1] != '\\')
	{
		SrcFN[SrcDirLen]= '\\';
		SrcFN[SrcDirLen+ 1]= 0;
		SrcDirLen++;
	}

	if (eFN[eDirLen- 1] != '\\')
	{
		eFN[eDirLen]= '\\';
		eFN[eDirLen+ 1]= 0;
		eDirLen++;
	}

	if (nFN[nDirLen- 1] != '\\')
	{
		nFN[nDirLen]= '\\';
		nFN[nDirLen+ 1]= 0;
		nDirLen++;
	}

	wcscpy(RsltFN, RsltDir);
	if (RsltFN[RsltDirLen- 1] != '\\')
	{
		RsltFN[RsltDirLen]= '\\';
		RsltFN[RsltDirLen+ 1]= 0;
		RsltDirLen++;
	}

	if (hBuildThrd != NULL) 
	{
		::MessageBox(m_hWnd, L"This directory is already processed by detector.\nSelect another directory and try again", L"User error", MB_OK);
		return;
	}

  GetDlgItem(IDC_BUTTON_BUILD)->EnableWindow(FALSE);
  GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(TRUE);

	hBuildThrd= CreateThread(NULL, 0, BuildThrdProc, NULL, 0, NULL); 
}

void CBuilderDlg::OnEnChangeEditScriptDir()
{
 	WIN32_FIND_DATA FindData;
	HANDLE hFind= INVALID_HANDLE_VALUE;
 	TCHAR FindMask[MAX_PATH+ 1]; //, Str[32]; 
	int ScriptCnt= 0;
	int Len;
	DWORD i; 
	int j, Ind, Ratio, Val;

	::SendMessage(GuiParams.hScriptListBoxWnd, LB_RESETCONTENT, 0, 0);

	GetDlgItemText(IDC_EDIT_SCRIPT_DIR, ScriptDir, MAX_PATH+ 1);
	i= ::GetFileAttributes(ScriptDir);
	if (i == INVALID_FILE_ATTRIBUTES)
	{
		return;
	}
	i&= FILE_ATTRIBUTE_DIRECTORY;
	if (i  == 0)
		return;

	wcscpy(FindMask, ScriptDir);
	wcscat(FindMask, L"\\*.txt");
	hFind= ::FindFirstFile(FindMask, &FindData);
	if (hFind == INVALID_HANDLE_VALUE)
	{
		return;
	}
  do
	{
//		j= atoi((LPARAM)FindData.cFileName
		j= wcslen(FindData.cFileName);
		j-= 5;
		Ratio= 1;
		Val= 0;
		do
		{
			Val+= Ratio* (FindData.cFileName[j]- 0x30);
			Ratio*= 10;
			j--;
		}
		while (j >= 0);

		j= ScriptCnt- 1;
		while (j >= 0) 
		{
			Ind= ::SendMessage(GuiParams.hScriptListBoxWnd, LB_GETITEMDATA, j, 0);
			if (Val >= Ind)
			{
				j++;
				break;
			}
			j--;
		}
//		Len= wcslen(FindData.cFileName);
		if (j < 0)
			j= 0;
		i= ::SendMessage(GuiParams.hScriptListBoxWnd, LB_INSERTSTRING, j, (LPARAM)FindData.cFileName);
		::SendMessage(GuiParams.hScriptListBoxWnd, LB_SETITEMDATA, i, (LPARAM)Val); 
		ScriptCnt++;
	}
	while (::FindNextFile(hFind, &FindData));
	FindClose(hFind);
}

void CBuilderDlg::OnEnChangeEditEDir()
{
	int i;

	GetDlgItemText(IDC_EDIT_E_DIR, eDir, MAX_PATH+ 1);
	i= ::GetFileAttributes(eDir);
	if (i == INVALID_FILE_ATTRIBUTES)
	{
		eDir[0]= 0;
		return;
	}
	i&= FILE_ATTRIBUTE_DIRECTORY;
	if (i  == 0)
	{
		eDir[0]= 0;
		return;
	}
}

void CBuilderDlg::OnEnChangeEditSrcDir()
{
	int i;

	GetDlgItemText(IDC_EDIT_SRC_DIR, SrcDir, MAX_PATH+ 1);
	i= ::GetFileAttributes(SrcDir);
	if (i == INVALID_FILE_ATTRIBUTES)
	{
		SrcDir[0]= 0;
		return;
	}
	i&= FILE_ATTRIBUTE_DIRECTORY;
	if (i  == 0)
	{
		SrcDir[0]= 0;
		return;
	}
}

void CBuilderDlg::OnEnChangeEditNDir()
{
	int i;

	GetDlgItemText(IDC_EDIT_N_DIR, nDir, MAX_PATH+ 1);
	i= ::GetFileAttributes(nDir);
	if (i == INVALID_FILE_ATTRIBUTES)
	{
		nDir[0]= 0;
		return;
	}
	i&= FILE_ATTRIBUTE_DIRECTORY;
	if (i  == 0)
	{
		nDir[0]= 0;
		return;
	}
}

void CBuilderDlg::OnEnChangeEditRsltDir()
{
	int i;

	GetDlgItemText(IDC_EDIT_RSLT_DIR, RsltDir, MAX_PATH+ 1);
	i= ::GetFileAttributes(RsltDir);
	if (i == INVALID_FILE_ATTRIBUTES)
	{
		RsltDir[0]= 0;
		return;
	}
	i&= FILE_ATTRIBUTE_DIRECTORY;
	if (i  == 0)
	{
		RsltDir[0]= 0;
		return;
	}
}

/*
BOOL ChangeDirList(TCHAR *InitialDir)
{
	int i;
 	WIN32_FIND_DATA FindData;
	HANDLE hFind= INVALID_HANDLE_VALUE;
 	TCHAR FindMask[MAX_PATH+ 1]; 
	int Len;
	
	i= ::GetFileAttributes(InitialDir);
  if (i == INVALID_FILE_ATTRIBUTES)
	{
		return FALSE;
	}
	i&= FILE_ATTRIBUTE_DIRECTORY;
	if (i  == 0)
		return FALSE;

// !!!!	::SendMessage(GuiParams.hDirListBoxWnd, LB_RESETCONTENT, 0, 0); 

//	i= wcslen(InitialDir)
	wcscpy(FindMask, InitialDir);
	wcscat(FindMask, L"\\*");
	hFind= ::FindFirstFile(FindMask, &FindData);
	if (hFind == INVALID_HANDLE_VALUE)
	{
//		::MessageBox(0, L"Impossibly to find txt files in specified directory", L"Error", MB_OK);
		return FALSE;
	}
  do
	{
		if ((FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) == 0)
			continue;
		if ((FindData.cFileName[0] == '.') && (FindData.cFileName[1] == 0))
			continue;
// !!!!		::SendMessage(GuiParams.hDirListBoxWnd, LB_ADDSTRING, 0, (LPARAM)FindData.cFileName);
	}
	while (::FindNextFile(hFind, &FindData));

	wcscpy(DirPath, InitialDir);

	return TRUE;
}

void CBuilderDlg::OnCbnEditchangeCombo1()
{
 	WIN32_FIND_DATA FindData;
	HANDLE hFind= INVALID_HANDLE_VALUE;
  TCHAR Str[MAX_PATH+ 1];
 	TCHAR FindMask[MAX_PATH+ 1]; 
	int Len;
	DWORD i;
	static int DirCnt= 0;
	
	i= ::SendMessage(GuiParams.hDirComboBoxWnd, CB_GETCURSEL, 0, 0);
	if (i != -1)
	{
// !!!!		::SendMessage(GuiParams.hDirComboBoxWnd, CB_GETLBTEXT, i, (LPARAM)Str);
//		i= ::SendMessage(GuiParams.hDirComboBoxWnd, CB_SETCURSEL, -1, 0);
//		SetDlgItemText(IDC_COMBO_DIR, DirPath);
	}
	else
		GetDlgItemText(IDC_COMBO_DIR, Str, MAX_PATH+ 1);

	ChangeDirList(Str);

}

void CBuilderDlg::OnLbnDblclkList2()
{
	int i, j;
  TCHAR Str[MAX_PATH+ 1];

	i= ::SendMessage(GuiParams.hDirListBoxWnd, LB_GETCURSEL, 0, 0);
	if (i == LB_ERR)
	{
		::MessageBox(m_hWnd, L"Select a script from the list to process", L"User error", MB_OK);
		return;
	}

	wcscpy(Str, DirPath);
	j= wcslen(Str);
	Str[j]= '\\';
	j++;
	i= ::SendMessage(GuiParams.hDirListBoxWnd, LB_GETTEXT, i, (LPARAM)&Str[j]);
  if (i == 0)
	{
		::MessageBox(m_hWnd, L"Unexcpected error\nError code: #0001", L"System error", MB_OK);
		return;
	}
	if (Str[j+ i- 1] == '.')
	{
		j+= (i- 3);
		Str[j]= 0;
//		j= j+ i- 3;
		do
		{
			j--;
		}
		while ((Str[j] != '\\') && (j > 0));
		Str[j]= 0;
	}
	if (ChangeDirList(Str))
	{
		SetDlgItemText(IDC_COMBO_DIR, Str); 
	}
}


void CBuilderDlg::OnBnClickedButtonBuild0()
{
	char Str[32];
	int i;
	CWaitCursor WaitCursor;
	std::vector<WAV_MAP_DATA>::iterator pWavItem;

	if ((SrcDir[0] == 0) || (eDir[0] == 0) || (nDir[0] == 0))
	{
		::MessageBox(m_hWnd, L"One of directories is not exist.\nCheck the directory pathes", L"User error", MB_OK);
		return;
	}

	if (pBeepBuff != NULL)
	{
		LocalFree(pBeepBuff);
		pBeepBuff= NULL;
	}
	i= LoadFileToBuff(BeepFN, &pBeepBuff);	
  if ((i == 0) || (i == INVALID_FILE_SIZE))
	{
		::MessageBox(::GetTopWindow(0), L"Unable to load beep.wav.\nCheck if this file exist in progrm directory", L"Input data error", MB_OK | MB_ICONERROR);\
		return;
	}
	if (*(DWORD *)pBeepBuff != 0x46464952)				// "RIFF"
	{
		::MessageBox(::GetTopWindow(0), L"beep.wav is wrong.\nCheck if this file exist in progrm directory", L"Input data error", MB_OK | MB_ICONERROR);\
		return;
	}
	i= 16+ *(DWORD *)&pBeepBuff[16];
	while (*(DWORD *)&pBeepBuff[i] != 0x61746164) // "data", skip additional header
		i++;
	pTotalLenVal= (DWORD *)&pBeepBuff[4];
	pDataLenVal= (DWORD *)&pBeepBuff[i+ 4];
	BeepDataLen= *pDataLenVal;
	InitialLen= *pTotalLenVal- BeepDataLen;
	HdrLen= i+ 8;
	pBeepData= pBeepBuff+ HdrLen;
  GetFormatInfo(pBeepBuff, &BeepInfo);
	PauseBytesCnt= BeepInfo.nAvgBytesPerSec; // >> 1;
	pPauseData= (char *)LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT, PauseBytesCnt);
	SamplesPerSec= BeepInfo.nSamplesPerSec;

	wcscpy(ScriptFN, ScriptDir);

	if (wcscmp(SrcDirPrev, SrcDir) != 0)
	{
		wcscpy(SrcDirPrev, SrcDir);
		wcscpy(SrcFN, SrcDir);
		CLEAR_WAV_DATA_LIST(SrcWavDataList)
	}
	if (wcscmp(eDirPrev, eDir) != 0)
	{
		wcscpy(eDirPrev, eDir);
		wcscpy(eFN, eDir);
		CLEAR_WAV_DATA_LIST(eWavDataList)
	}
	if (wcscmp(nDirPrev, nDir) != 0)
	{
		wcscpy(nDirPrev, nDir);
		wcscpy(nFN, nDir);
		CLEAR_WAV_DATA_LIST(nWavDataList)
	}

	ScriptDirLen= wcslen(ScriptDir);
	SrcDirLen= wcslen(SrcDir);
	eDirLen= wcslen(eDir);
	nDirLen= wcslen(nDir);

	if (ScriptFN[SrcDirLen- 1] != '\\')
	{
		ScriptFN[ScriptDirLen]= '\\';
		ScriptFN[ScriptDirLen+ 1]= 0;
		ScriptDirLen++;
	}

	if (SrcFN[SrcDirLen- 1] != '\\')
	{
		SrcFN[SrcDirLen]= '\\';
		SrcFN[SrcDirLen+ 1]= 0;
		SrcDirLen++;
	}

	if (eFN[eDirLen- 1] != '\\')
	{
		eFN[eDirLen]= '\\';
		eFN[eDirLen+ 1]= 0;
		eDirLen++;
	}

	if (nFN[eDirLen- 1] != '\\')
	{
		nFN[nDirLen]= '\\';
		nFN[nDirLen+ 1]= 0;
		nDirLen++;
	}

	if (hBuildThrd != NULL) 
	{
		::MessageBox(m_hWnd, L"This directory is already processed by detector.\nSelect another directory and try again", L"User error", MB_OK);
		return;
	}

  GetDlgItem(IDC_BUTTON_BUILD)->EnableWindow(FALSE);
  GetDlgItem(IDC_BUTTON_BUILD0)->EnableWindow(FALSE);
  GetDlgItem(IDC_BUTTON_BUILD1)->EnableWindow(FALSE);

	hBuildThrd= CreateThread(NULL, 0, BuildMultiSrcThrdProc, NULL, 0, NULL); 
}

*/
void CBuilderDlg::OnBnClickedButtonBuildLevel1()
{
//	char Str[32];
	int i;
	CWaitCursor WaitCursor;
	std::vector<WAV_MAP_DATA>::iterator pWavItem;

	if ((SrcDir[0] == 0) || (eDir[0] == 0) || (nDir[0] == 0))
	{
		::MessageBox(m_hWnd, L"One of directories is not exist.\nCheck the directory pathes", L"User error", MB_OK);
		return;
	}

	if (pBeepBuff != NULL)
	{
		LocalFree(pBeepBuff);
		pBeepBuff= NULL;
	}
	i= LoadFileToBuff(BeepFN, &pBeepBuff);	
  if ((i == 0) || (i == INVALID_FILE_SIZE))
	{
		::MessageBox(::GetTopWindow(0), L"Unable to load beep.wav.\nCheck if this file exist in progrm directory", L"Input data error", MB_OK | MB_ICONERROR);\
		return;
	}
	if (*(DWORD *)pBeepBuff != 0x46464952)				// "RIFF"
	{
		::MessageBox(::GetTopWindow(0), L"beep.wav is wrong.\nCheck if this file exist in progrm directory", L"Input data error", MB_OK | MB_ICONERROR);\
		return;
	}
	i= 16+ *(DWORD *)&pBeepBuff[16];
	while (*(DWORD *)&pBeepBuff[i] != 0x61746164) // "data", skip additional header
		i++;
/*
	TotalLenPos= 4;
	DataLenPos= i+ 4;
*/
	pTotalLenVal= (DWORD *)&pBeepBuff[4];
	pDataLenVal= (DWORD *)&pBeepBuff[i+ 4];
	BeepDataLen= *pDataLenVal;
	InitialLen= *pTotalLenVal- BeepDataLen;
	HdrLen= i+ 8;
	pBeepData= pBeepBuff+ HdrLen;
  GetFormatInfo(pBeepBuff, &BeepInfo);
	PauseBytesCnt= BeepInfo.nAvgBytesPerSec; // >> 1;
	pPauseData= (char *)LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT, PauseBytesCnt);
	SamplesPerSec= BeepInfo.nSamplesPerSec;

	wcscpy(ScriptFN, ScriptDir);

	if (wcscmp(SrcDirPrev, SrcDir) != 0)
	{
		wcscpy(SrcDirPrev, SrcDir);
		wcscpy(SrcFN, SrcDir);
		CLEAR_WAV_DATA_LIST(SrcWavDataList)
	}
	if (wcscmp(eDirPrev, eDir) != 0)
	{
		wcscpy(eDirPrev, eDir);
		wcscpy(eFN, eDir);
		CLEAR_WAV_DATA_LIST(eWavDataList)
	}
	if (wcscmp(nDirPrev, nDir) != 0)
	{
		wcscpy(nDirPrev, nDir);
		wcscpy(nFN, nDir);
		CLEAR_WAV_DATA_LIST(nWavDataList)
	}

	ScriptDirLen= wcslen(ScriptDir);
	SrcDirLen= wcslen(SrcDir);
	eDirLen= wcslen(eDir);
	nDirLen= wcslen(nDir);

	if (ScriptFN[SrcDirLen- 1] != '\\')
	{
		ScriptFN[ScriptDirLen]= '\\';
		ScriptFN[ScriptDirLen+ 1]= 0;
		ScriptDirLen++;
	}

	if (SrcFN[SrcDirLen- 1] != '\\')
	{
		SrcFN[SrcDirLen]= '\\';
		SrcFN[SrcDirLen+ 1]= 0;
		SrcDirLen++;
	}

	if (eFN[eDirLen- 1] != '\\')
	{
		eFN[eDirLen]= '\\';
		eFN[eDirLen+ 1]= 0;
		eDirLen++;
	}

	if (nFN[eDirLen- 1] != '\\')
	{
		nFN[nDirLen]= '\\';
		nFN[nDirLen+ 1]= 0;
		nDirLen++;
	}

	if (hBuildThrd != NULL) 
	{
		::MessageBox(m_hWnd, L"This directory is already processed by detector.\nSelect another directory and try again", L"User error", MB_OK);
		return;
	}

  GetDlgItem(IDC_BUTTON_BUILD)->EnableWindow(FALSE);
  GetDlgItem(IDC_BUTTON_BUILD1)->EnableWindow(FALSE);

	hBuildThrd= CreateThread(NULL, 0, BuildThrdProc, (LPVOID)1, 0, NULL); 
}

#define CHECK_DATA(CNTRL_ID, Dir)\
	GetDlgItemText(CNTRL_ID, Dir, MAX_PATH+ 1);\
	i= ::GetFileAttributes(Dir);\
	if (i == INVALID_FILE_ATTRIBUTES)\
	{\
		Dir[0]= 0;\
		MessageBox(GuiParams.hDlg, L"Wrong directory name", L"User error", MB_OK);\
	}\
	i&= FILE_ATTRIBUTE_DIRECTORY;\
	if (i == 0)\
	{\
		Dir[0]= 0;\
		MessageBox(GuiParams.hDlg, L"Wrong directory name", L"User error", MB_OK);\
	}

#define LOAD_DATA(TmpDir, DirMultiWavDataList, Ind)\
	if (TmpDir(0) == 0)\
		DirMultiWavDataList[Ind].Dir[0]= 0;\
	else\
	{\
		wcscpy(DirMultiWavDataList[Ind].Dir, TmpDir);\
		DirMultiWavDataList[Ind].Dir[j]= '\\';\
		wcscpy(SrcMultiWavDataList[Ind].FN, SrcMultiWavDataList[Ind].Dir);\
		wcscat(SrcMultiWavDataList[Ind].FN, L"\\");\
		SrcMultiWavDataList[DirInd].DirLen= wcslen(SrcMultiWavDataList[DirInd].FN);

DWORD CALLBACK BuildLevelThrdProc(LPVOID LevelParam)
{
	TCHAR RsltFN[MAX_LEVEL5_SUBDIR_CNT][MAX_PATH+ 1];
	TCHAR *pRsltFN;
	WAVEFORMATEX CurrFormat;
	int DataInd;
  char *pData;
  int i, j, LineCnt, Cnt;
	DWORD BytesCnt;
	DWORD ToWriteCnt;
	int FileSize, ScriptLen, FileCnt= 0;
	char *pScriptBuff= NULL;
	char *pStr, *pValStr;
	BOOL Continue= FALSE, EofScript;
	BOOL IsErr= FALSE;
	static int SamplePerSec= 0;
	int ErrCnt= 0;
	char ErrDescr[1024];
	std::vector<WAV_MAP_DATA>::iterator pWavItem;
	WAV_MAP_DATA *pWavData, WavData;
//	int PauseByteCnt;
	int DataLen;
	HANDLE hRsltLevelFile, hFile;
	BUILT_STATE State= BS_UNDEFINED, State0;
	char *pWriteData;
	int PauseBytesCnt0, PauseBytesCnt1;
	double PauseDuration;
//	int ScriptList[25];
	int ScriptCnt, ScriptInd= 0;
	int DirCnt, DirInd;
//	int DirList[5];
	int ScriptFrom, ScriptTo;
	int Level;

	if (::WaitForSingleObject(hBuildMutex, INFINITE) != WAIT_OBJECT_0)
		LogErr("WaitForSingleObject");

// 1	 1-141
// 2 142-441
// 3 442-720
// 4 721-805
// 5 806-882

	Level= (int)LevelParam;
  
	if (StopLevelBuild[Level])
	{
		StopLevelBuild[Level]= FALSE;
		SendMessage(GuiParams.hDlg, WM_LEVEL_BUILD_DONE, 0, Level);
		return 0;
	}

	LevelInBuild[Level]= TRUE;

	switch (Level)
	{
		case 0:
			ScriptFrom= 1;
			ScriptTo= 141;
//			ScriptCnt= 141;
		break;

		case 1:
			ScriptFrom= 142;
			ScriptTo= 441;
		break;

		case 2:
			ScriptFrom= 442;
			ScriptTo= 720;
		break;

		case 3:
			ScriptFrom= 721;
			ScriptTo= 805;
		break;

		case 4:
			ScriptFrom= 806;
			ScriptTo= 882;
		break;
	}

		ScriptCnt= ScriptTo- ScriptFrom+ 1;
		ScriptInd= 0;

		if (Level < 4)
		{
			DirCnt= 1;
			DirInd= 0;
			wcscpy(RsltFN[0], RsltLevelDir[Level]);
		}
		else
		{
			DirCnt= 2;
			wcscpy(RsltFN[0], RsltLevelDir[4]);
			wcscpy(RsltFN[1], RsltLevelDir[5]);
		}

	do
	{   
		hRsltLevelFile= NULL;

		if (ScriptFrom <= 9)
			wsprintf(&ScriptFN[ScriptDirLen], L"0%i.txt", ScriptFrom);
		else
			wsprintf(&ScriptFN[ScriptDirLen], L"%i.txt", ScriptFrom);

		ScriptLen= LoadFileToBuff(ScriptFN, &pScriptBuff);
		if (ScriptLen == INVALID_FILE_SIZE)
		{
			if (ScriptFrom <= 9)
			{
				wsprintf(&ScriptFN[ScriptDirLen], L"%i.txt", ScriptFrom);
				ScriptLen= LoadFileToBuff(ScriptFN, &pScriptBuff);
				if (ScriptLen == INVALID_FILE_SIZE)
				{
					IsErr= TRUE;
					ErrCnt++;
//					LOG_INFO
					LogMsg("Impossibly to load script");
					goto FINALIZE;
				}
			}
			else
			{
				IsErr= TRUE;
				ErrCnt++;
//				LOG_INFO
				LogMsg("Impossibly to load script");
				goto FINALIZE;
			}
		}
		SendMessage(GuiParams.hDlg, WM_LEVEL_REFRESH_INFO, 0, (LPARAM)&ScriptFN[ScriptDirLen]);

  	DataLen= 0;
    
		if (Level == 4)
		{
			DirInd= (DWORD)ScriptFrom & 1;
			DirInd^= 1;
			if ((SrcLevel5WavDataList[DirInd].FN[0] == 0) || (eLevel5WavDataList[DirInd].FN[0] == 0))
				goto FINALIZE;
		}
		pRsltFN= RsltFN[DirInd];
		pRsltFN+= (RsltLevelDirLen[Level+ DirInd]);
		wcscpy(pRsltFN, &ScriptFN[ScriptDirLen]);
		i= wcslen(pRsltFN);
		pRsltFN+= (i- 3);
//		wcscpy(pRsltFN, L"wav");
		wcscpy(pRsltFN, L"dat");

		hRsltLevelFile= CreateFile(RsltFN[DirInd], GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL); 
		if (hRsltLevelFile == INVALID_HANDLE_VALUE)
		{
			IsErr= TRUE;
			ErrCnt++;
			LOG_INFO
			LogMsg("%ws", RsltFN[DirInd]);
			LogErr("Impossibly to create a target file. CreateFile");
			goto FINALIZE;
		}
		
		if (SetFilePointer(hRsltLevelFile, HdrLen, NULL, FILE_BEGIN) != HdrLen)
		{
			IsErr= TRUE;
			ErrCnt++;
			LOG_INFO
			LogErr("SetFilePointer");
			goto FINALIZE;
		}
		if (!SetEndOfFile(hRsltLevelFile))
		{
			IsErr= TRUE;
			ErrCnt++;
			LOG_INFO
			LogErr("SetEndOfFile");
			goto FINALIZE;
		}

		IsErr= FALSE;
		pStr= pScriptBuff;
		pStr[ScriptLen]= 0;
		EofScript= FALSE;
		i= 0;
		LineCnt= 0;
		do
		{
			State= BS_UNDEFINED;
			switch (*pStr)
			{
				case '<':
					do
					{
						pStr++;
						i++;
					}
					while (*pStr != 0x0D);
					GO_TO_NEXT_LINE
				break;
	
				case 'E':
					if (*(pStr+ 1) != '-')
					{
// script error
						ERR_MSG_BREAK("no '-' after E")
//						break;
					}
					pStr+= 2;
					i+= 2;
					GET_VAL
//					FIND_WAV_DATA(eWavDataList)
//					LOAD_WAV_DATA(e)
					State= BS_WRITE_E_DATA;
				break;
				
				case 'n':
					if (*(pStr+ 1) != '-')
					{
// script error
						ERR_MSG_BREAK("no '-' after n")
//						break;
					}
					pStr+= 2; 
					i+= 2; 
					GET_VAL
//					FIND_WAV_DATA(nWavDataList)
//					LOAD_WAV_DATA(n)
					State= BS_WRITE_N_DATA;
				break;
				
				case 'p':
					if (*(pStr+ 1) == '#')
					{
						pStr+= 2; 
						i+= 2;
						GET_VAL
//						FIND_WAV_DATA(SrcWavDataList)
//						LOAD_WAV_DATA(Src)
						State= BS_WRITE_PAUSE;
					}
					else
					{
						pStr++;
						i++;
						PauseBytesCnt0= 0;
						PauseBytesCnt1= 0;
						pValStr= pStr;
						Cnt= 0;
						do
						{
							Cnt++;
							pStr++;
							i++;
						}
						while (((*pStr >= '0') && (*pStr <= '9')) || (*pStr == '.'));
						GO_TO_NEXT_LINE
						PauseDuration= atof(pValStr);
						PauseBytesCnt1= PauseBytesCnt* PauseDuration;
						if ((PauseBytesCnt1 & 1) != 0)
							PauseBytesCnt1++;
						if (PauseDuration > 1)
						{
							PauseBytesCnt0= PauseBytesCnt1/ PauseBytesCnt;
							PauseBytesCnt1= PauseBytesCnt1 % PauseBytesCnt;
						}

						State= BS_WRITE_PAUSE_VAL;
					}
				break;
				case 'B':
				case 'b':
					if (*(DWORD *)pStr == 0x50454542)   // beep
					{
						pStr+= 4; 
						i+= 4; 
						State= BS_WRITE_BEEP;
						GO_TO_NEXT_LINE
					}
				break;

				case 0x0D:
				case 0x0A:
					i++;
					EofScript= TRUE;;
				break;
				
				default:
					if ((*pStr < '0') || (*pStr > '9'))
					{
						IsErr= TRUE;
						ErrCnt++;
						ERR_MSG_BREAK("Wrong symbol.")
					}
					GET_VAL
//					FIND_WAV_DATA(SrcWavDataList)
//					LOAD_WAV_DATA(Src)
					State= BS_WRITE_SRC_DATA;
			}
	
			if (hRsltLevelFile == NULL)
				goto FINALIZE;
      if (StopLevelBuild[Level])
				break;

			State0= BS_UNDEFINED;
			switch (State)
			{
				case BS_WRITE_SRC_DATA:
//					FIND_WAV_DATA(SrcMultiWavDataList[DirInd].WavDataList)
//					LOAD_WAV_DATA(SrcMultiWavDataList[DirInd].)					
					switch (Level)
					{
						case 0:
							FIND_WAV_DATA(SrcLevel1WavDataList.WavDataList)
							LOAD_WAV_DATA(SrcLevel1WavDataList.)
						break;
						case 1:
							FIND_WAV_DATA(SrcLevel2WavDataList.WavDataList)
							LOAD_WAV_DATA(SrcLevel2WavDataList.)
						break;
						case 2:
							FIND_WAV_DATA(SrcLevel3WavDataList.WavDataList)
							LOAD_WAV_DATA(SrcLevel3WavDataList.)
						break;
						case 3:
							FIND_WAV_DATA(SrcLevel4WavDataList.WavDataList)
							LOAD_WAV_DATA(SrcLevel4WavDataList.)
						break;
						case 4:
							if ((SrcLevel5WavDataList[DirInd].FN[0] == 0) || (eLevel5WavDataList[DirInd].FN[0] == 0))
								break;
							FIND_WAV_DATA(SrcLevel5WavDataList[DirInd].WavDataList)
							LOAD_WAV_DATA(SrcLevel5WavDataList[DirInd].)
						break;
					}
					State0= BS_WRITE_WAV;
				break;

				case BS_WRITE_E_DATA:
//					FIND_WAV_DATA(eWavDataList)
//					LOAD_WAV_DATA(e)
					switch (Level)
					{
						case 0:
							FIND_WAV_DATA(eLevel1WavDataList.WavDataList)
							LOAD_WAV_DATA(eLevel1WavDataList.)
						break;
						case 1:
							FIND_WAV_DATA(eLevel2WavDataList.WavDataList)
							LOAD_WAV_DATA(eLevel2WavDataList.)
						break;
						case 2:
							FIND_WAV_DATA(eLevel3WavDataList.WavDataList)
							LOAD_WAV_DATA(eLevel3WavDataList.)
						break;
						case 3:
							FIND_WAV_DATA(eLevel4WavDataList.WavDataList)
							LOAD_WAV_DATA(eLevel4WavDataList.)
						break;
						case 4:
							if ((SrcLevel5WavDataList[DirInd].FN[0] == 0) || (eLevel5WavDataList[DirInd].FN[0] == 0))
								break;
							FIND_WAV_DATA(eLevel5WavDataList[DirInd].WavDataList)
							LOAD_WAV_DATA(eLevel5WavDataList[DirInd].)
						break;
					}
					State0= BS_WRITE_WAV;
				break;

				case BS_WRITE_N_DATA:
					FIND_WAV_DATA(nWavDataList)
					LOAD_WAV_DATA(n)
					State0= BS_WRITE_WAV;
				break;

				case BS_WRITE_PAUSE:
//					FIND_WAV_DATA(SrcMultiWavDataList[DirInd].WavDataList)
//					LOAD_WAV_DATA(SrcMultiWavDataList[DirInd].)
					switch (Level)
					{
						case 0:
							FIND_WAV_DATA(SrcLevel1WavDataList.WavDataList)
							LOAD_WAV_DATA(SrcLevel1WavDataList.)
						break;
						case 1:
							FIND_WAV_DATA(SrcLevel2WavDataList.WavDataList)
							LOAD_WAV_DATA(SrcLevel2WavDataList.)
						break;
						case 2:
							FIND_WAV_DATA(SrcLevel3WavDataList.WavDataList)
							LOAD_WAV_DATA(SrcLevel3WavDataList.)
						break;
						case 3:
							FIND_WAV_DATA(SrcLevel4WavDataList.WavDataList)
							LOAD_WAV_DATA(SrcLevel4WavDataList.)
						break;
						case 4:
							if (((LevelDataList[Level].peLevelWavDataList+ DirInd)->FN[0] == 0) || ((LevelDataList[Level].pSrcLevelWavDataList+ DirInd)->FN[0] == 0))
								break;
							FIND_WAV_DATA(SrcLevel5WavDataList[DirInd].WavDataList)
							LOAD_WAV_DATA(SrcLevel5WavDataList[DirInd].)
						break;
					}
//					State0= BS_WRITE_PAUSE_VAL;
//				break;
				case BS_WRITE_PAUSE_VAL:
					State0= BS_WRITE_PAUSE_VAL;
				break;

				case BS_WRITE_BEEP:
					State0= BS_WRITE_BEEP;
				break;
			}	

			if (StopLevelBuild[Level])
				break;

			switch (State0)
			{
				case BS_WRITE_WAV:
					if (!WriteFile(hRsltLevelFile, pWriteData, ToWriteCnt, &BytesCnt, NULL) || (ToWriteCnt != BytesCnt))
					{
						ERR_LOG_BREAK("WriteFile: Data")
					}
					DataLen+= ToWriteCnt;
				break;
				
				case BS_WRITE_BEEP:
					if (!WriteFile(hRsltLevelFile, pBeepData, BeepDataLen, &BytesCnt, NULL) || (BeepDataLen != BytesCnt))
					{
						ERR_LOG_BREAK("WriteFile: Beep")
					}
					DataLen+= BeepDataLen;
				break;

				case BS_WRITE_PAUSE_VAL:
					Cnt= PauseBytesCnt0;
					while (Cnt > 0)
					{
						if (!WriteFile(hRsltLevelFile, pPauseData, PauseBytesCnt, &BytesCnt, NULL) || (PauseBytesCnt != BytesCnt))
						{
							ERR_LOG_BREAK("WriteFile:PauseData0")
						}
						Cnt--;
						DataLen+= PauseBytesCnt;
					}
					if (PauseBytesCnt1 > 0)
					{
						if (!WriteFile(hRsltLevelFile, pPauseData, PauseBytesCnt1, &BytesCnt, NULL) || (PauseBytesCnt1 != BytesCnt))
						{
							ERR_LOG_BREAK("WriteFile:PauseData1")
						}
						DataLen+= PauseBytesCnt1;
					}
				break;
			}
		}
		while ((i < ScriptLen) && (!IsErr) && (!EofScript) && (!StopLevelBuild[Level]));

		if (StopLevelBuild[Level])
			break;

FINALIZE:
		if (hRsltLevelFile != NULL)
		{
			if (SetFilePointer(hRsltLevelFile, 0, NULL, FILE_BEGIN) != 0)
			{
				IsErr= TRUE;
				ErrCnt++;
				LogErr("SetFilePointer: FILE_BEGIN");
			}
			else
			{
				*pTotalLenVal= InitialLen+ DataLen;
				*pDataLenVal= DataLen;
				if (!WriteFile(hRsltLevelFile, pBeepBuff, HdrLen, &BytesCnt, NULL) || (HdrLen != BytesCnt))
				{
					IsErr= TRUE;
					ErrCnt++;
					LogErr("WriteFile: wav header");
				}
			}

			::FlushFileBuffers(hRsltLevelFile);
			CloseHandle(hRsltLevelFile);
/*
			if (::WaitForSingleObject(hMp3Mutex, INFINITE) != WAIT_OBJECT_0)
			{
				LogErr("WaitForSingleObject(hMp3Mutex)");
			}
			if (!::FinalizeMp3File(RsltFN[DirInd]))
				ErrCnt++;
			::ReleaseMutex(hMp3Mutex);
			DeleteFile(RsltFN[DirInd]);
*/
			hRsltLevelFile= NULL;
		}
		ScriptInd++;
		ScriptFrom++;
	}
	while ((ScriptInd < ScriptCnt) && (!StopLevelBuild[Level]));
 	LocalFree(pScriptBuff);
	pScriptBuff= NULL;

	switch (Level)
	{
		case 0:
			CLEAR_WAV_DATA_LIST(eLevel1WavDataList.WavDataList)
			CLEAR_WAV_DATA_LIST(SrcLevel1WavDataList.WavDataList)
		break;
		case 1:
			CLEAR_WAV_DATA_LIST(eLevel2WavDataList.WavDataList)
			CLEAR_WAV_DATA_LIST(SrcLevel2WavDataList.WavDataList)
		break;
		case 2:
			CLEAR_WAV_DATA_LIST(eLevel3WavDataList.WavDataList)
			CLEAR_WAV_DATA_LIST(SrcLevel3WavDataList.WavDataList)
		break;
		case 3:
			CLEAR_WAV_DATA_LIST(eLevel4WavDataList.WavDataList)
			CLEAR_WAV_DATA_LIST(SrcLevel4WavDataList.WavDataList)
		break;
		case 4:
			CLEAR_WAV_DATA_LIST(eLevel5WavDataList[0].WavDataList)
			CLEAR_WAV_DATA_LIST(SrcLevel5WavDataList[0].WavDataList)
			CLEAR_WAV_DATA_LIST(eLevel5WavDataList[1].WavDataList)
			CLEAR_WAV_DATA_LIST(SrcLevel5WavDataList[1].WavDataList)
		break;
	}

	StopLevelBuild[Level]= FALSE;
	LevelInBuild[Level]= FALSE;

	::ReleaseMutex(hBuildMutex);

	SendMessage(GuiParams.hDlg, WM_LEVEL_BUILD_DONE, ErrCnt, Level);

	return 0;
}

void CBuilderDlg::OnBnClickedButtonSelectAll()
{
	::SendMessage(GuiParams.hScriptListBoxWnd, LB_SETSEL, 1, -1); 
}

void CBuilderDlg::OnBnClickedButtonUnselectAll()
{
	::SendMessage(GuiParams.hScriptListBoxWnd, LB_SETSEL, 0, -1); 
}

void CBuilderDlg::OnBnClickedButtonStop()
{
	StopBuild= TRUE;
	GetDlgItem(IDC_BUTTON_BUILD)->EnableWindow(FALSE);
}


