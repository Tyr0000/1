// PlayerDlg.h : header file
//

#pragma once


// CBuilderDlg dialog
class CBuilderDlg : public CDialog
{
// Construction
public:
	CBuilderDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_BUILDER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation

	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDestroy();
protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
public:
	afx_msg void OnBnClickedButtonBuild();
public:
	afx_msg void OnEnChangeEditScriptDir();
public:
	afx_msg void OnEnChangeEditEDir();
public:
	afx_msg void OnEnChangeEditSrcDir();
public:
	afx_msg void OnEnChangeEditNDir();
public:
	afx_msg void OnBnClickedButtonBuildLevel1();
public:
	afx_msg void OnBnClickedButtonSelectAll();
public:
	afx_msg void OnBnClickedButtonUnselectAll();
public:
	afx_msg void OnBnClickedButtonStop();
public:
	afx_msg void OnEnChangeEditRsltDir();
};
