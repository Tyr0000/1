#include "mmsystem.h"
#include "DirUtility.h"

#pragma warning (disable: 4996)

#define MAX_BUFF_LEN			1024*1000*2
#define MAX_BUFF_NUM			3

#define SNAP_DURATION			0.1
#define GAP_DURATION	    0.01
#define THRESHOLD_STEP	  0x5FF // 32767/ 10	

#define WM_REFRESH_INFO			WM_USER+ 1
#define WM_PLAY_DONE			  WM_USER+ 2
#define WM_DO_PAUSE		  	  WM_USER+ 3
#define WM_DETECT_DONE			WM_USER+ 4

typedef enum _PLAYER_MODE
{
	PM_WAIT,
	PM_PLAYING,
	PM_PAUSED
} PLAYER_MODE;

typedef struct _PLAYER_PARAMS
{
	WAVEFORMATEX *pFormat;
	char *pBuff;
	int BuffLen;
} PLAY_PLAYER_PARAMS;

extern HANDLE 
//	hExitEvnt,
	hPlayEvnt,
	hStopEvnt,
	hPauseEvnt,
	hResumeEvnt;

//extern PLAYER_MODE PlayerMode;
extern TCHAR WorkDir[MAX_PATH+ 1]; 
extern FILE_LIST *pPlayFileList;
extern BOOL PlayContinuonesly;
extern int SeriesLen;
extern BOOL SkipSilence;
extern int ThresholdRatio;
extern int StartFile;
extern TCHAR CurrFileStr[16];

BOOL InitPlayerParams(HWND hGuiWnd);
void ClearPlayerParams();
BOOL StartPlayer();
void StopPlayer();
BOOL PausePlayer();

int LoadFileToBuff(TCHAR *FileName, char *pFileBuff);

int GetSampleBuff(char *pInFileBuff, int *pDataLen);
void GetFormatInfo(char *pBuff, WAVEFORMATEX *pFormat);
void PlayBack(WAVEFORMATEX *pFormat, char *pBuff, int BuffLen);
