#define WM_REFRESH_INFO							WM_USER+ 1
#define WM_PLAY_DONE							WM_USER+ 2
#define WM_DO_PAUSE		  					WM_USER+ 3
#define WM_DETECT_DONE							WM_USER+ 4
#define WM_TRIM_DONE							WM_USER+ 5
#define WM_BUILD_DONE							WM_USER+ 6
#define WM_LEVEL_BUILD_DONE						WM_USER+ 7
#define WM_LEVEL_REFRESH_INFO						WM_USER+ 8

