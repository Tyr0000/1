#include "stdafx.h"
#include "mmsystem.h"

#include "BladeMP3EncDLL.h"

#ifndef _LAME_DLL
#pragma comment (lib, "..\\Utility\\mp3LameEnc.lib")
#endif

#include "LogFile.h"

#pragma warning (disable: 4996)

extern WAVEFORMATEX BeepInfo;	
// extern HANDLE hMp3Mutex;
extern BOOL StopBuild;
extern BOOL StopLevelBuild[5];

#define IF_IS_STOP_BUILD\
	if (StopBuild || StopLevelBuild[0] || StopLevelBuild[1] || StopLevelBuild[2] || StopLevelBuild[3] || StopLevelBuild[4])

char							*pMp3Buff;
	
//extern unsigned __int64 freq, begin, end;
//extern float ReadTime, WriteTime, CalcTime;


#ifdef _LAME_DLL

	BEINITSTREAM			beInitStream= NULL;
	BEENCODECHUNK			beEncodeChunk= NULL;
	BEDEINITSTREAM		beDeinitStream= NULL;
	BECLOSESTREAM			beCloseStream= NULL;
	BEVERSION					beVersion= NULL;
	BEWRITEVBRHEADER	beWriteVBRHeader= NULL;
	BEWRITEINFOTAG		beWriteInfoTag= NULL;
	HMODULE						hDllLame= NULL;

BOOL LoadLameLib(TCHAR *pWorkDir)
{	
	TCHAR LamePath[MAX_PATH];

	wcscpy(LamePath, pWorkDir);
	wcscat(LamePath, L"\\lame_enc.dll");

	if (hDllLame != NULL)
		return TRUE;

	hDllLame = LoadLibrary(LamePath);
	if(hDllLame == NULL)
	{
//		GetErrDescr(_T("LoadLibrary(\"lame_enc.dll\")"));
//		::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
		return FALSE;
	}

	beInitStream			= (BEINITSTREAM) GetProcAddress(hDllLame, TEXT_BEINITSTREAM);
	beEncodeChunk			= (BEENCODECHUNK) GetProcAddress(hDllLame, TEXT_BEENCODECHUNK);
	beDeinitStream		= (BEDEINITSTREAM) GetProcAddress(hDllLame, TEXT_BEDEINITSTREAM);
	beCloseStream			= (BECLOSESTREAM) GetProcAddress(hDllLame, TEXT_BECLOSESTREAM);
	beVersion					= (BEVERSION) GetProcAddress(hDllLame, TEXT_BEVERSION);
	beWriteVBRHeader	= (BEWRITEVBRHEADER) GetProcAddress(hDllLame,TEXT_BEWRITEVBRHEADER);
	beWriteInfoTag		= (BEWRITEINFOTAG) GetProcAddress(hDllLame,TEXT_BEWRITEINFOTAG);
	if(!beInitStream || !beEncodeChunk || !beDeinitStream || !beCloseStream || !beVersion || !beWriteVBRHeader)
	{
//		STR_CPY(ErrDescr, _T("Unable to get LAME interfaces from Lame dll"));
//		::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
		return FALSE;
	}
	return TRUE;
}
#endif

BOOL FinalizeMp3File(TCHAR *SampleFile)
{
FILE*		pFileIn			=NULL;
FILE*		pFileOut		=NULL;
//	BE_VERSION	Version			={0,};
BE_CONFIG		beConfig			={0,};
DWORD				dwSamples			=0;
DWORD				dwMP3Buffer		=0;
HBE_STREAM	hbeStream			=0;
BE_ERR			err						=0;

PBYTE		pMP3Buffer		=NULL;
PSHORT		pWAVBuffer		=NULL;

char mp3FN[MAX_PATH+ 1];
TCHAR mp3File[MAX_PATH+ 1];
int Len;

#ifdef _UNICODE
	wcscpy(mp3File, SampleFile);
	Len= (int)wcslen(mp3File);
	mp3File[Len- 3]= 'm';
	mp3File[Len- 2]= 'p';
	mp3File[Len- 1]= '3';
::WideCharToMultiByte(CP_ACP, 0, mp3File, -1, mp3FN, MAX_PATH+ 1, NULL, NULL );    
#else
	strcpy(mp3File, SampleFile);
	Len= strlen(mp3File);
	mp3File[Len- 3]= 'm';
	mp3File[Len- 2]= 'p';
	mp3File[Len- 1]= '3';
	STR_CPY(mp3FN, mp3File);
#endif

	pFileIn = _tfopen(SampleFile, _T("rb") );
	if(pFileIn == NULL)
	{
		LogErr("FinalizeMp3File: FOPEN(SampleFile)");
		return FALSE;
	}

	pFileOut= _tfopen(mp3File, _T("wb+"));
	if(pFileOut == NULL)
	{
		LogErr("FinalizeMp3File: FOPEN(mp3File)");
		return FALSE;
	}

	memset(&beConfig, 0, sizeof(beConfig));					// clear all fields
	beConfig.dwConfig = BE_CONFIG_LAME;
	beConfig.format.LHV1.dwStructVersion	= 1;
	beConfig.format.LHV1.dwStructSize			= sizeof(beConfig);		
	beConfig.format.LHV1.dwSampleRate			= BeepInfo.nSamplesPerSec;
	beConfig.format.LHV1.dwReSampleRate		= 0;										// DON"T RESAMPLE
	beConfig.format.LHV1.nMode 						= BE_MP3_MODE_MONO- (BeepInfo.nChannels- 1);
	beConfig.format.LHV1.dwBitrate				= 128;
	beConfig.format.LHV1.nPreset					= LQP_CBR; 
//	beConfig.format.LHV1.nPreset					= LQP_ABR;
//	beConfig.format.LHV1.nPreset					= LQP_VOICE_QUALITY;

	beConfig.format.LHV1.dwMpegVersion		= MPEG1;								// MPEG VERSION (I or II)
	beConfig.format.LHV1.dwPsyModel				= 0;										// USE DEFAULT PSYCHOACOUSTIC MODEL 
	beConfig.format.LHV1.dwEmphasis				= 0;										// NO EMPHASIS TURNED ON
	beConfig.format.LHV1.bOriginal				= TRUE;									// SET ORIGINAL FLAG
	beConfig.format.LHV1.bWriteVBRHeader	= TRUE;									// Write INFO tag
	beConfig.format.LHV1.bNoRes							= TRUE;								// No Bit resorvoir
//	beConfig.format.LHV1.dwMaxBitrate			= 320;								// MAXIMUM BIT RATE
//	beConfig.format.LHV1.bCRC							= TRUE;								// INSERT CRC
//	beConfig.format.LHV1.bCopyright				= TRUE;								// SET COPYRIGHT FLAG	
//	beConfig.format.LHV1.bPrivate					= TRUE;								// SET PRIVATE FLAG
//	beConfig.format.LHV1.bWriteVBRHeader	= TRUE;								// YES, WRITE THE XING VBR HEADER
//	beConfig.format.LHV1.bEnableVBR				= TRUE;								// USE VBR
		beConfig.format.LHV1.bEnableVBR	= FALSE;
/*
	beConfig.format.LHV1.bEnableVBR	= TRUE;
	beConfig.format.LHV1.nVBRQuality			= 5;									// SET VBR QUALITY
	beConfig.format.LHV1.nVbrMethod= VBR_METHOD_ABR;
*/

	IF_IS_STOP_BUILD
		return TRUE;

	err = beInitStream(&beConfig, &dwSamples, &dwMP3Buffer, &hbeStream);
	if(err != BE_ERR_SUCCESSFUL)
	{
		LogMsg("\tFinalizeMp3File: beInitStream");
		return FALSE;
	}

	pMP3Buffer = new BYTE[dwMP3Buffer];
	pWAVBuffer = new SHORT[dwSamples];
	if(!pMP3Buffer || !pWAVBuffer)
	{
//		STR_CPY(ErrDescr, _T("Impossibly to allocate memory for mp3 buffer"));
//		::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
		LogMsg("\tFinalizeMp3File: Impossibly to allocate memory for mp3 buffer");
		return FALSE;
	}

	DWORD dwRead=0;
	DWORD dwWrite=0;
	DWORD dwDone=0;

	fseek(pFileIn,0,SEEK_END);

	if (ftell(pFileIn) < 11025)
	{
		fclose( pFileOut );
		DeleteFile(mp3File);
		return TRUE;
	}
//!!!!	fseek(pFileIn,44,SEEK_SET);
	fseek(pFileIn, 0, SEEK_SET);

	IF_IS_STOP_BUILD
		goto FINALIZE;

	while ( (dwRead= (DWORD)fread(pWAVBuffer,sizeof(SHORT),dwSamples,pFileIn)) >0 )
	{
		err = beEncodeChunk(hbeStream, dwRead, pWAVBuffer, pMP3Buffer, &dwWrite);
		if(err != BE_ERR_SUCCESSFUL)
		{
			beCloseStream(hbeStream);
//			SPRINTF(ErrDescr, _T("beEncodeChunk() failed (%lu)"), err);
//			::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
			LogMsg("\tFinalizeMp3File: beEncodeChunk- %i", err);
			return FALSE;
		}
		if(fwrite(pMP3Buffer,1,dwWrite,pFileOut) != dwWrite)
		{
//			STR_CPY(ErrDescr, _T("Output file write error"));
//			::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
			LogMsg("\tFinalizeMp3File: fwrite(pMP3Buffer)");
			return FALSE;
		}

		dwDone += dwRead*sizeof(SHORT);

		IF_IS_STOP_BUILD
		break;
	}
FINALIZE:

	err = beDeinitStream(hbeStream, pMP3Buffer, &dwWrite);
	if(err != BE_ERR_SUCCESSFUL)
	{
		beCloseStream(hbeStream);

//		SPRINTF(ErrDescr, _T("beExitStream failed (%lu)"), err);
//		::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
			LogMsg("\tFinalizeMp3File: beDeinitStream");
		return FALSE;
	}
	if( dwWrite )
	{
		if( fwrite( pMP3Buffer, 1, dwWrite, pFileOut ) != dwWrite )
		{
//			STR_CPY(ErrDescr, _T("Output file write error"));
//			::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
			LogMsg("\tFinalizeMp3File: fwrite( deInit)");
			return FALSE;
		}
 	}

	beCloseStream( hbeStream );

	delete [] pWAVBuffer;
	delete [] pMP3Buffer;

	fclose( pFileIn );
	fclose( pFileOut );

	if ( beWriteInfoTag != NULL )
	{
		err= beWriteInfoTag( hbeStream, (LPCSTR)mp3FN );
		if(err != BE_ERR_SUCCESSFUL)
		{
//			SPRINTF(ErrDescr, _T("Lame library internal error: nbeWriteInfoTag\n ErrCode:#(%lu)"), err);
//			::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
			LogMsg("\tFinalizeMp3File: beWriteInfoTag");
			return FALSE;
		}
	}
	else
	{
		err= beWriteVBRHeader((LPCSTR)mp3FN);
		if(err != BE_ERR_SUCCESSFUL)
		{
//			SPRINTF(ErrDescr, _T("Lame library internal error: beWriteVBRHeader\n ErrCode:#(%lu)"), err);
//			::MessageBox(0, ErrDescr, _T("Recorder error"), MB_OK);
			LogMsg("\tFinalizeMp3File: beWriteVBRHeader");
			return FALSE;
		}
	}

	return TRUE;
}

