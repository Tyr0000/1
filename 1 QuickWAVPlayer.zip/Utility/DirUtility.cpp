#include "stdafx.h"
#include "DirUtility.h"

#pragma warning (disable: 4996)

static FILE_ENTRY *pFileList= NULL;

FILE_ENTRY *GetFileList(TCHAR *pWorkDir)
{
	int Cnt= 0, i, Len;
	int Ratio;
	char Val;

 	WIN32_FIND_DATA FindData;
	HANDLE hFind= INVALID_HANDLE_VALUE ;
	TCHAR FindMask[MAX_PATH+ 1]; 
//	TCHAR FN[MAX_PATH+ 1];
  FILE_ENTRY *pCurrEntry, *pPrevEntry, *pTmpEntry= NULL, *pSortedEntry;

	ClearFileList();

 	wcscpy(FindMask, pWorkDir);
	wcscat(FindMask, L"\\*.wav");
	hFind= ::FindFirstFile(FindMask, &FindData);
	if (hFind == INVALID_HANDLE_VALUE)
	{
		::MessageBox(0, L"Impossibly to find wav files in playing directory", L"Error", MB_OK);
		return NULL;
	}
  do
	{
 //   pFileEntry= new FILE_ENTRY;
		Len= wcslen(FindData.cFileName);
		pCurrEntry= (FILE_ENTRY *)LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT, sizeof(FILE_ENTRY)+ Len* sizeof(TCHAR));
		if (pFileList == NULL)
		{
			pFileList= pCurrEntry;
			pPrevEntry= pCurrEntry;
		}
		else
		{
//			pPrevEntry->pNextEntry= pCurrEntry;
		}
// LMEM_ZEROINIT
//		pCurrEntry->pNextEntry= NULL;
//			pCurrEntry->Ind= 0
//		wcscpy(pCurrEntry, FindData.cFileName);
		pCurrEntry->IsSelected= FALSE;
		pCurrEntry->Len= Len;
    for (i= Len- 1; i >= Len- 4; i--) // .wav
			pCurrEntry->FN[i]= FindData.cFileName[i];
		Ratio= 1;
//		pCurrEntry->Val= 0;
		do
		{
			pCurrEntry->FN[i]= FindData.cFileName[i];
			Val= pCurrEntry->FN[i];
			Val-= 0x30;
			pCurrEntry->Val+= Ratio* Val;
			Ratio*= 10;
			i--;
		}
		while (i >= 0);
//		pCurrEntry->Ind= Cnt;
		if (Cnt > 0)
		{
			pTmpEntry= pFileList;
			pSortedEntry= NULL;
			while ((pTmpEntry != NULL) && (pCurrEntry->Val > pTmpEntry->Val))
			{
				pSortedEntry= pTmpEntry;
				pTmpEntry= (FILE_ENTRY *)pTmpEntry->pNextEntry;
			} 
			if (pSortedEntry == NULL)
			{
				pCurrEntry->pNextEntry= pFileList;
				pFileList= pCurrEntry;
				continue;
			}
			if (pTmpEntry != NULL)
			{
				pSortedEntry->pNextEntry= pCurrEntry;
				pCurrEntry->pNextEntry= pTmpEntry;

/*
				pCurrEntry->Ind= j;
				while (pTmpEntry != NULL) // replace rest of array index
				{
					pTmpEntry->Ind++;
					pTmpEntry= (FILE_ENTRY *)pTmpEntry->pNextEntry;
				}
*/
			}
			else
			{
				pPrevEntry->pNextEntry= pCurrEntry;
				pPrevEntry= pCurrEntry;
			}
		}
		Cnt++;
	}
	while (::FindNextFile(hFind, &FindData));
	return pFileList;
}

void ClearFileList()
{
	FILE_ENTRY *pCurrEntry, *pTmpEntry;

	if (pFileList == NULL)
		return;

	pCurrEntry=(FILE_ENTRY *)pFileList->pNextEntry;
	while (pCurrEntry != NULL)
	{
		pTmpEntry= pCurrEntry;
		pCurrEntry= (FILE_ENTRY *)pCurrEntry->pNextEntry;
		LocalFree(pTmpEntry);
	}
	LocalFree(pFileList);
	pFileList= NULL;
}

BOOL FILE_LIST::GetFileList(TCHAR *pWorkDir)
{
	int Cnt= 0, i, Len;
	int Ratio;
	char Val;

 	WIN32_FIND_DATA FindData;
	HANDLE hFind= INVALID_HANDLE_VALUE ;
	TCHAR FindMask[MAX_PATH+ 1]; 
//	TCHAR FN[MAX_PATH+ 1];
  FILE_ENTRY *pCurrEntry, *pPrevEntry, *pTmpEntry= NULL, *pSortedEntry;

	FILE_LIST::ClearFileList();

 	wcscpy(FindMask, pWorkDir);
	wcscat(FindMask, L"\\*.wav");
	hFind= ::FindFirstFile(FindMask, &FindData);
	if (hFind == INVALID_HANDLE_VALUE)
	{
		::MessageBox(0, L"Impossibly to find wav files in playing directory", L"Error", MB_OK);
		return FALSE;
	}
  do
	{
 //   pFileEntry= new FILE_ENTRY;
		Len= wcslen(FindData.cFileName);
		pCurrEntry= (FILE_ENTRY *)LocalAlloc(LMEM_FIXED | LMEM_ZEROINIT, sizeof(FILE_ENTRY)+ Len* sizeof(TCHAR));
		if (m_pFileList == NULL)
		{
			m_pFileList= pCurrEntry;
			pPrevEntry= pCurrEntry;
		}
		else
		{
//			pPrevEntry->pNextEntry= pCurrEntry;
		}
// LMEM_ZEROINIT
//		pCurrEntry->pNextEntry= NULL;
//			pCurrEntry->Ind= 0
//		wcscpy(pCurrEntry, FindData.cFileName);
		pCurrEntry->IsSelected= FALSE;
		pCurrEntry->Len= Len;
    for (i= Len- 1; i >= Len- 4; i--) // .wav
			pCurrEntry->FN[i]= FindData.cFileName[i];
		Ratio= 1;
//		pCurrEntry->Val= 0;
		do
		{
			pCurrEntry->FN[i]= FindData.cFileName[i];
			Val= pCurrEntry->FN[i];
			Val-= 0x30;
			pCurrEntry->Val+= Ratio* Val;
			Ratio*= 10;
			i--;
		}
		while (i >= 0);
//		pCurrEntry->Ind= Cnt;
		if (Cnt > 0)
		{
			pTmpEntry= m_pFileList;
			pSortedEntry= NULL;
			while ((pTmpEntry != NULL) && (pCurrEntry->Val > pTmpEntry->Val))
			{
				pSortedEntry= pTmpEntry;
				pTmpEntry= (FILE_ENTRY *)pTmpEntry->pNextEntry;
			} 
			if (pSortedEntry == NULL)
			{
				pCurrEntry->pNextEntry= m_pFileList;
				m_pFileList= pCurrEntry;
				continue;
			}
			if (pTmpEntry != NULL)
			{
				pSortedEntry->pNextEntry= pCurrEntry;
				pCurrEntry->pNextEntry= pTmpEntry;

/*
				pCurrEntry->Ind= j;
				while (pTmpEntry != NULL) // replace rest of array index
				{
					pTmpEntry->Ind++;
					pTmpEntry= (FILE_ENTRY *)pTmpEntry->pNextEntry;
				}
*/
			}
			else
			{
				pPrevEntry->pNextEntry= pCurrEntry;
				pPrevEntry= pCurrEntry;
			}
		}
		Cnt++;
	}
	while (::FindNextFile(hFind, &FindData));
	return TRUE;
}

void FILE_LIST::ClearFileList()
{
	FILE_ENTRY *pCurrEntry, *pTmpEntry;

	if (m_pFileList == NULL)
		return;

	pCurrEntry=(FILE_ENTRY *)m_pFileList->pNextEntry;
	while (pCurrEntry != NULL)
	{
		pTmpEntry= pCurrEntry;
		pCurrEntry= (FILE_ENTRY *)pCurrEntry->pNextEntry;
		LocalFree(pTmpEntry);
	}
	LocalFree(m_pFileList);
	m_pFileList= NULL;
}
