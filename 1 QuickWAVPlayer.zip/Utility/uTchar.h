#pragma once
#include "tchar.h"

#pragma once

#pragma warning (disable: 4996)

#ifndef STR_LEN
#ifdef _UNICODE
#define STR_LEN					wcslen
#define STR_CPY					wcscpy
#define STR_CAT					wcscat
#define STR_CMP					wcscmp
#define SPRINTF					wsprintf
#else
#define STR_LEN					strlen
#define STR_CPY					strcpy
#define STR_CAT					strcat
#define STR_CMP					strcmp
#define SPRINTF   			sprintf
#endif
#endif
