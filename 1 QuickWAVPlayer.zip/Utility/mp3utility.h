#include "BladeMP3EncDLL.h"
#include <tchar.h>

#ifdef _LAME_DLL
BOOL LoadLameLib(TCHAR *pWorkDi);
#endif

BOOL FinalizeMp3File(TCHAR *SampleFile);
