#include "stdafx.h"
#include <math.h>
#include "WavUtility.h"

#pragma comment(lib, "Winmm.lib")

//FILE_LIST *pFiles;

static PLAYER_MODE PlayerMode= PM_WAIT;
TCHAR WorkDir[MAX_PATH+ 1];
FILE_LIST *pPlayFileList;
BOOL PlayContinuonesly;
int SeriesLen;
BOOL SkipSilence;
int ThresholdRatio= 0;
//int StartFile= 0;
TCHAR CurrFileStr[16];
HWND hWnd;

HANDLE 
//	hExitEvnt,
	hPlayEvnt,
	hStopEvnt,
	hPauseEvnt,
	hResumeEvnt,
	hSynchEvnt;
//	hLoadBuffEvnt;
// HANDLE hSyncMutex;

#define MAX_EVNT_NUM			5

HANDLE hPlayingThrd= NULL, hCntrlThrd= NULL;

//char WavBuff[1024*5*2][3];
HGLOBAL hBuff0, hBuff1, hBuuf2;

char *pBuff0, *pBuff1, *pBuff2;

int PlayInd= -1, LoadInd= -1;
PLAY_PLAYER_PARAMS PlayerParams[3];

BOOL InitPlayerParams(HWND hGuiWnd)
{
	BOOL Rslt= TRUE;
	HANDLE *phEvnts[MAX_EVNT_NUM]= {&hPlayEvnt, &hStopEvnt, &hPauseEvnt, &hResumeEvnt, &hSynchEvnt};
  int i;

	hWnd= hGuiWnd;
__try
{
	for (i= 0; i < MAX_EVNT_NUM; i++)
	{
		*phEvnts[i]= CreateEvent(NULL, FALSE, FALSE, NULL);
		if (*phEvnts[i] == NULL)
		{
			::MessageBox(0, L"Impossibly to initialize player", L"Error", MB_OK);
			Rslt= FALSE;
			__leave;
		}
	}
}
__finally
{
	if (!Rslt)
		ClearPlayerParams();
}
	return Rslt;
}

void ClearPlayerParams()
{
	HANDLE *phEvnts[MAX_EVNT_NUM]= {&hPlayEvnt, &hStopEvnt, &hPauseEvnt, &hResumeEvnt, &hSynchEvnt};
  int i;

	for (i= 0; i < MAX_EVNT_NUM; i++)
		if (*phEvnts[i] != NULL)
			CloseHandle(*phEvnts[i]);
}

int LoadFileToBuff(TCHAR *FileName, char *pFileBuff)
{
  HANDLE hFile;
	unsigned long FileSize, i;

	hFile= CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL); 
	if (hFile == INVALID_HANDLE_VALUE)
	{
	  ::MessageBox(::GetTopWindow(0), L"Impossibly to read from file.\n\nTo copy this error message into clipboard press Ctrl-C", L"Error", MB_OK | MB_ICONERROR);
    return INVALID_FILE_SIZE;
	}

	FileSize= GetFileSize(hFile, &i);
	if (FileSize == 0)
	{
		CloseHandle(hFile);
		return 0;
	}
	if (FileSize == INVALID_FILE_SIZE)
	{
		::MessageBox(::GetTopWindow(0), L"Impossibly to read from file.\n\nTo copy this error message into clipboard press Ctrl-C", L"Error", MB_OK | MB_ICONERROR);
		CloseHandle(hFile);
    return INVALID_FILE_SIZE;
	}
	
	if (FileSize > MAX_BUFF_LEN)
	{
		::MessageBox(::GetTopWindow(0), L"File is too long", L"Error", MB_OK | MB_ICONERROR);
		CloseHandle(hFile);
    return INVALID_FILE_SIZE;
	}

  if ((!ReadFile(hFile, pFileBuff, FileSize, &i, NULL)) || (i != FileSize))
	{
		CloseHandle(hFile);
		::MessageBox(::GetTopWindow(0), L"Impossibly to read from file.\n\nTo copy this error message into clipboard press Ctrl-C", L"Error", MB_OK | MB_ICONERROR);
    return INVALID_FILE_SIZE;
	}
	CloseHandle(hFile);
	return FileSize;
}

int GetSampleBuff(char *pInFileBuff, int *pDataLen)
{
// Find ADPCM samples
// RIFF WAVE fmt- 16 bits
	DWORD ChunkSize;
/*
	WORD  FormatTag; 
  WORD  NumChannels; 
  DWORD SamplesPerSec; 
  DWORD AvgBytesPerSec; 
  WORD  BlockAlign; 
	WORD  BitsPerSample;
*/
	int DataInd= 0;

	ChunkSize=			 *(DWORD *)&pInFileBuff[16];
/*
	FormatTag=			 *(WORD *)&pInFileBuff[20]; 
	NumChannels=		 *(WORD *)&pInFileBuff[22]; 
	SamplesPerSec=	 *(DWORD *)&pInFileBuff[24]; 
	AvgBytesPerSec=	 *(DWORD *)&pInFileBuff[28]; 
	BlockAlign=			 *(WORD *)&pInFileBuff[32]; 
	BitsPerSample=   *(WORD *)&pInFileBuff[34]; 
*/
	DataInd= 16+ ChunkSize;
	while (*(DWORD *)&pInFileBuff[DataInd] != 0x61746164) // "data", skip additional header
		DataInd++;
	ChunkSize=			*(DWORD *)&pInFileBuff[DataInd+ 4];	// data length
  DataInd+= 8;

	*pDataLen= ChunkSize;

	return DataInd;
}

void GetFormatInfo(char *pBuff, WAVEFORMATEX *pFormat)
{
	DWORD ChunkSize;
	int DataInd= 0;

	ChunkSize= *(DWORD *)&pBuff[16];

	DataInd= 16+ ChunkSize;
	while (*(DWORD *)&pBuff[DataInd] != 0x61746164) // "data", skip additional header
		DataInd++;
	ChunkSize=	*(DWORD *)&pBuff[DataInd+ 4];	// data length

	pFormat->wFormatTag=				*(WORD *)&pBuff[20];				// WAVE_FORMAT_PCM;
	pFormat->nAvgBytesPerSec=		*(DWORD *)&pBuff[28];				// 16000;
	pFormat->nBlockAlign=				*(WORD *)&pBuff[32];				// 2;
	pFormat->nChannels=					*(WORD *)&pBuff[22];				// 1;
	pFormat->nSamplesPerSec=		*(DWORD *)&pBuff[24];				// 8000;
  pFormat->wBitsPerSample=		*(WORD *)&pBuff[34];				//16;
//	pFormat->cbSize=						ChunkSize;
}

void SendRefreshMsg(TCHAR *pFN)
{
	SendMessage(hWnd, WM_REFRESH_INFO, (WPARAM) pFN, 0);
}

HWAVEOUT hWaveOut= NULL;
WAVEFORMATEX WaveFormat;

void CALLBACK WaveOutCallbackProc(HWAVEOUT hWaveOut, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
{
	switch (uMsg)
	{
		case WOM_OPEN:
			SetEvent(hPlayEvnt);
		break;
		case WOM_DONE:
//			waveOutUnprepareHeader(hWaveOut, &Hdr, sizeof(WAVEHDR));
//			waveOutClose(hWaveOut);
//			if (PlayerMode == PM_PLAYING)
				SetEvent(hPlayEvnt);
		break;
    case WOM_CLOSE:
				SetEvent(hStopEvnt);
		break;
	}
}

void CloseWaveDevice()
{
	if (hWaveOut == NULL)
		return;

	waveOutClose(hWaveOut);
	hWaveOut= NULL;

	if (WaitForSingleObject(hStopEvnt, 2500) != WAIT_OBJECT_0)
	{
//		MessageBeep(0);
	}
}

BOOL OpenWaveDevice(WAVEFORMATEX *pFormat)
{
	DWORD Instance= 0xFF;

	if (hWaveOut == NULL)
	{
		if (waveOutOpen(NULL, WAVE_MAPPER, pFormat, NULL, 0, WAVE_FORMAT_QUERY | WAVE_ALLOWSYNC) != MMSYSERR_NOERROR)
		{
			::MessageBox(0, L"Impossibly to open audio device to play back", L"Error", MB_OK);
			return FALSE;
		}
		if (waveOutOpen(&hWaveOut, WAVE_MAPPER, pFormat, (DWORD_PTR)WaveOutCallbackProc, (DWORD_PTR)&Instance, WAVE_FORMAT_DIRECT | WAVE_ALLOWSYNC | CALLBACK_FUNCTION) != MMSYSERR_NOERROR)
		{
			::MessageBox(0, L"Impossibly to open audio device to play back", L"Error", MB_OK);
			return FALSE;
		}
		if (WaitForSingleObject(hPlayEvnt, 2500) != WAIT_OBJECT_0)
		{
			::MessageBox(0, L"Impossibly to open audio device to play back", L"Error", MB_OK);
			return FALSE;
		}
		PlayerMode= PM_PLAYING;
		WaveFormat= *pFormat;
	}
	return TRUE;
}

int SnapLen;
int GapLen;

DWORD WINAPI PlayingThrdProc(LPVOID lpVoid)
{
  BOOL Rslt= TRUE;
	HANDLE hEvnts[MAX_EVNT_NUM]= {hPlayEvnt, hStopEvnt, hPauseEvnt, hResumeEvnt};
	int FileCnt= 0;
  BOOL Continue= TRUE;
//	BOOL SkipFile= FALSE;

  FILE_ENTRY *pFileEntry;
	TCHAR FN[MAX_PATH+ 1];

	WAVEFORMATEX CurrFormat;
	WAVEHDR WaveHdr;
  char *pData;
	char *pWaveBuff; 
	int DataInd, Len;
	float Duration;
	pWaveBuff= new char[MAX_BUFF_LEN];

	pFileEntry= pPlayFileList;

do
{

	if (PlayerMode == PM_PLAYING)
	{
// load file
		wsprintf(FN, L"%ws\\%s", WorkDir, pFileEntry->FN);
		Len= LoadFileToBuff(FN, pWaveBuff);
		if (Len == INVALID_FILE_SIZE)
		{
	//		delete [] pWaveBuff;
	//		return 1;
			Continue= FALSE;
			continue;
		}
		else
			if (Len == 0)
				continue;

//		SendMessage(hWnd, WM_REFRESH_INFO, (WPARAM)pFileEntry, 0);
		SendMessage(hWnd, WM_REFRESH_INFO, (WPARAM)pFileEntry->FN, (LPARAM)pFileEntry);

		if (*(DWORD *)pWaveBuff == 0x46464952)				// "RIFF"
		{
			DataInd= GetSampleBuff(pWaveBuff, &Len);
			GetFormatInfo(pWaveBuff, &CurrFormat); 
			pData= (char *)(pWaveBuff+ DataInd); 
			CurrFormat.cbSize= 0;
  		if (!OpenWaveDevice(&CurrFormat))
			{
				Continue= FALSE;
				continue;
			}
			Duration= ((float)Len)/ (CurrFormat.nSamplesPerSec * CurrFormat.nBlockAlign);
			SnapLen= SNAP_DURATION* CurrFormat.nAvgBytesPerSec; //(CurrFormat.nSamplesPerSec * CurrFormat.nBlockAlign);
			GapLen= GAP_DURATION* CurrFormat.nAvgBytesPerSec; //(CurrFormat.nSamplesPerSec * CurrFormat.nBlockAlign);
		}
		else
			continue;
// skip silence -32768 to 32767

		if (Duration <= 1.0)
			if (SkipSilence && (CurrFormat.wFormatTag == WAVE_FORMAT_PCM) && (CurrFormat.wBitsPerSample == 16))			
//				SkippingSilence(&pData, &Len);

		{
		int Skip= 0;
		signed __int16 *pSample;
		signed __int16 Val, Threshold;
    int Min= 0, Max= -32767, Min00= 0, Max00= -32767, Min01= 0, Max01= -32767, d0, d1, i;
    
		pSample= (signed __int16 *)pData;
		for (i= 0; i < Len; i++)
		{
			Val= abs((signed __int16)pSample[i]);
			if (Min > Val)
				Min= Val;
			if (Max < Val)
				Max= Val;
			
			if (i == SnapLen)
			{
				Min00= Min;
				Max00= Max;
			}
		}

		i= (Max- Min) / 30;
		d0= (Max00- Min00) / 30;
		d1= (Max01- Min01) / 25;

		{
			pSample= (signed __int16 *)pData;
			Skip= 0; 
      Threshold= 0x007F;
			if (ThresholdRatio != 0)
				Threshold= Min+ 2*i + ThresholdRatio*i;
			while(TRUE)
			{
				Val=(signed __int16)pSample[Skip];
				if (abs(Val) > Threshold)
//				if (abs(Val) > 0x0F00)
					break;
				Skip++;
			}
//			if (Skip == 0)
//				Skip= SnapLen* 2;

			pSample= (signed __int16 *)(pData+ Len- 2);
			pData+= 2* Skip;
			Len-= 2* Skip;

			Skip= 0; 
      Threshold= 0x0100;
			if (ThresholdRatio != 0)
				Threshold= Min+ 2*i+ ThresholdRatio*i;
//				Threshold= Max01+ ThresholdRatio* d1;
			while(TRUE)
			{
				Val=(signed __int16)*pSample;
				if (abs(Val) > Threshold)
//				if (abs(Val) > 0x0700)
					break;
				pSample--;
				Skip++;
			}
			Len-= 2* Skip;
		}
//		if (Skip == 0)
//			Len-= SnapLen;

//		Skip= Len % (CurrFormat.nSamplesPerSec * CurrFormat.nBlockAlign);
		Skip= Len % 2; // CurrFormat.nBlockAlign;
		if (Skip > 0)
			Len-= Skip;
			}

// start playing
		WaveHdr.lpData= pData;
		WaveHdr.dwBufferLength= Len;
		WaveHdr.dwLoops= 1;
		WaveHdr.dwFlags= WHDR_BEGINLOOP | WHDR_ENDLOOP;
		if (waveOutPrepareHeader(hWaveOut, &WaveHdr, sizeof(WAVEHDR)) != MMSYSERR_NOERROR)
		{
			::MessageBox(0, L"Impossibly to prepare audio buffer to play back", L"Error", MB_OK);
			continue;
		}
		if (waveOutWrite(hWaveOut, &WaveHdr, sizeof(WAVEHDR)) != MMSYSERR_NOERROR)
		{
			::MessageBox(0, L"Impossibly to prepare audio buffer to play back", L"Error", MB_OK);
			waveOutUnprepareHeader(hWaveOut, &WaveHdr, sizeof(WAVEHDR));
			continue;
		}
	}
		switch (WaitForMultipleObjects(MAX_EVNT_NUM- 1, hEvnts, FALSE, INFINITE))
		{
			case WAIT_OBJECT_0:			// hPlayEvnt 
				switch (PlayerMode)
				{
					case PM_PAUSED:
						SetEvent(hSynchEvnt);

//						waveOutRestart(hWaveOut);
//						PlayerMode= PM_PLAYING;
//					break;
					case PM_PLAYING:
						if (waveOutUnprepareHeader(hWaveOut, &WaveHdr, sizeof(WAVEHDR)) != MMSYSERR_NOERROR)
						{
							::MessageBox(0, L"Impossibly to reset audiio device", L"Error", MB_OK);
//							Rslt= FALSE;
//							Continue= FALSE;
						}
						pFileEntry= (FILE_ENTRY *)pFileEntry->pNextEntry;
						if (pFileEntry == NULL)
						{
							Continue= FALSE;
						}
						if (!PlayContinuonesly)
						{
							FileCnt++;
							if (FileCnt == SeriesLen)
							{
								SendMessage(hWnd, WM_DO_PAUSE, 0, 0);
								FileCnt= 0;
								PlayerMode= PM_PAUSED;
							}
						}
					break;
//					case PM_WAIT:
//						Continue= FALSE;
//					break;
				}
			break;

			case WAIT_OBJECT_0+ 1: // hStopEvnt
			  waveOutReset(hWaveOut);

				PlayerMode= PM_WAIT;
				Continue= FALSE;
//				continue;
			break;

			case WAIT_OBJECT_0+ 2: // hPauseEvnt 
				PlayerMode= PM_PAUSED;
/*
				if (waveOutPause(hWaveOut) != MMSYSERR_NOERROR)
				{
					::MessageBox(0, L"Impossibly to pause audiio device", L"Error", MB_OK);
					Rslt= FALSE;
					Continue= FALSE;
				}
*/
			break;
//				continue;

			case WAIT_OBJECT_0+ 3: // hResumeEvnt
/*
				if (waveOutRestart(hWaveOut) != MMSYSERR_NOERROR)
				{
					::MessageBox(0, L"Impossibly to resume audio device", L"Error", MB_OK);
					Rslt= FALSE;
					Continue= FALSE;
				}
*/
				PlayerMode= PM_PLAYING;
			break;
//				continue;

			case WAIT_FAILED:
				::MessageBox(0, L"An error ocured during playing", L"Error", MB_OK);
				Rslt= FALSE;
				Continue= FALSE;
//			break;
				continue;
		}		
}
while (Continue);

//	waveOutUnprepareHeader(hWaveOut, &WaveHdr, sizeof(WAVEHDR);
	CloseWaveDevice();

	delete [] pWaveBuff;

	SendMessage(hWnd, WM_PLAY_DONE, Rslt, 0);
	PlayerMode= PM_WAIT;
	return Rslt^1;
}

BOOL StartPlayer()
{
	hPlayingThrd= ::CreateThread(NULL, 0, PlayingThrdProc, NULL, 0, 0);
	if (hPlayingThrd == 0)
		return FALSE;

	PlayerMode= PM_PLAYING;
}

void StopPlayer()
{
	SetEvent(hStopEvnt);
	if (WaitForSingleObject(hPlayingThrd, 500) != WAIT_OBJECT_0)
	{
		ResetEvent(hStopEvnt);
		if (hPlayingThrd != NULL)
			::TerminateThread(hPlayingThrd, 0);
	}
}

BOOL PausePlayer()
{
	SetEvent(hPauseEvnt);
	if (WaitForSingleObject(hSynchEvnt, 5000) != WAIT_OBJECT_0)
		return FALSE;
  return TRUE;
}