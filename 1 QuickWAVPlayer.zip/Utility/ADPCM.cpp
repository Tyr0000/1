#include "stdafx.h"
#include "mmsystem.h"
#include <mmreg.h>
#include <msacm.h>
#include <assert.h>
#pragma comment(lib, "Msacm32.lib")

#include "..\Utility\WavUtility.h"

#include "..\Utility\LogFile.h"

extern WAVEFORMATEX BeepInfo;
extern char *pBeepBuff, *pFmtData;
extern DWORD *pTotalLenVal, *pDataLenVal;
extern int InitialLen;

typedef struct WaveFormat : public tWAVEFORMATEX {

  BYTE Ext [128];
              // �������������� ��������� �������

} EX_WAVEFORMATEX;

EX_WAVEFORMATEX DestInfo;

BYTE	Ext[128]= {
		0xf4, 0x03, 0x07, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00, 0xff, 0x00, 0x00, 0x00, 0x00,
		0xc0, 0x00, 0x40, 0x00, 0xf0, 0x00, 0x00, 0x00, 0xcc, 0x01, 0x30, 0xff, 0x88, 0x01, 0x18, 0xff
};

//BYTE WavHdr[


#define WMA_BLOCK_SIZE 1000

#define SOURCE_WMA "D:\\Speech\\formula_1.pcm"
#define OUTPUT_PCM_FILE "d:\\Speech\\wma_simple.pcm"

HACMDRIVERID g_CCITT; 

HACMSTREAM hCnvrtStream = NULL;
DWORD DestBuffLen= 0;
BYTE *pDestBuff;

BOOL InitACM()
{
	MMRESULT Rslt;

	DestInfo.nChannels= BeepInfo.nChannels;
	DestInfo.wFormatTag      = WAVE_FORMAT_ADPCM;
  DestInfo.wBitsPerSample  = 4;
  DestInfo.nBlockAlign     = 512; 
	DestInfo.nSamplesPerSec  = BeepInfo.nSamplesPerSec;
  DestInfo.nAvgBytesPerSec = 11155;
  DestInfo.cbSize          = 32; 
 
	memcpy(DestInfo.Ext, Ext, 32);

  Rslt = acmStreamOpen(&hCnvrtStream, NULL, &BeepInfo, &DestInfo, NULL, 0, 0, 0);
 
  switch( Rslt )
  {
    case MMSYSERR_NOERROR:
      break; // success!
    case MMSYSERR_INVALPARAM:
      LogMsg( "Invalid parameters passed to acmStreamOpen" );
      return FALSE;
    case ACMERR_NOTPOSSIBLE:
      LogMsg( "No ACM filter found capable of decoding WMA" );
      return FALSE;
    default:
      LogMsg( "Some error opening ACM decoding stream!" );
      return FALSE;
  }
	return TRUE;
}

void ClearACM()
{
	acmStreamClose(hCnvrtStream, 0);
	hCnvrtStream= NULL;
}

BOOL CALLBACK acmDriverEnumCallback( HACMDRIVERID hadid, DWORD dwInstance, DWORD fdwSupport )
{
  if( fdwSupport & ACMDRIVERDETAILS_SUPPORTF_CODEC )
  {
    MMRESULT mmr;

    ACMDRIVERDETAILS details;
    details.cbStruct = sizeof(ACMDRIVERDETAILS);
    mmr = acmDriverDetails( hadid, &details, 0 );

    HACMDRIVER driver;
    mmr = acmDriverOpen( &driver, hadid, 0 );

    for (int i = 0; i < (int)details.cFormatTags; i++ )
    {
      ACMFORMATTAGDETAILS fmtDetails;
      ZeroMemory( &fmtDetails, sizeof(fmtDetails) );
      fmtDetails.cbStruct = sizeof(ACMFORMATTAGDETAILS);
      fmtDetails.dwFormatTagIndex = i;
      mmr = acmFormatTagDetails( driver, &fmtDetails, ACM_FORMATTAGDETAILSF_INDEX );

      if ( !wcscmp( fmtDetails.szFormatTag , L"CCITT A-Law" ) )
      {
        LogMsg( "%s\nTag = %i  TagIndex = %i\n" ,details.szLongName, fmtDetails.dwFormatTag , fmtDetails.dwFormatTagIndex );    
        g_CCITT = hadid;
      }
    }

    mmr = acmDriverClose( driver, 0 );
    return true;
  }

  return false;
}

void ChooseFormat(WAVEFORMATEX *wmaFormat, WAVEFORMATEX *wavFormat)
{
 ACMFORMATCHOOSE afc;
 int MaxSize;

 memset(&afc,0,sizeof(afc));
 afc.cbStruct=sizeof(afc);
 MaxSize=sizeof(WAVEFORMATEX);
 acmMetrics(0,ACM_METRIC_MAX_SIZE_FORMAT, &MaxSize);

 //afc.fdwStyle = ACMFORMATCHOOSE_STYLEF_INITTOWFXSTRUCT;
 afc.pwfx=wmaFormat;
 afc.cbwfx=MaxSize;

 afc.hwndOwner=NULL;
 afc.fdwEnum=ACM_FORMATENUMF_CONVERT ;
 afc.pwfxEnum=wavFormat;

 afc.pszTitle= L"Select new format";
 acmFormatChoose(&afc);
}

int ConvertToADPCM(TCHAR *FN, char *pSrcBuff, DWORD SrcBuffLen)
{
  MMRESULT Rslt;
	int ConvertedSamples, i, Ind;
 
	Rslt = acmStreamSize (hCnvrtStream, SrcBuffLen, (DWORD *)&DestBuffLen, ACM_STREAMSIZEF_SOURCE);
  if (Rslt != MMSYSERR_NOERROR) 
	{
		LogMsg ("acmStreamSize: DstBufferLen");
    return FALSE;
  }

  pDestBuff= (BYTE *)LocalAlloc(LMEM_FIXED, DestBuffLen);
  
  ACMSTREAMHEADER AH;

  AH.cbStruct = sizeof (ACMSTREAMHEADER);
  AH.fdwStatus = 0;
  AH.pbSrc = (BYTE *)pSrcBuff;
  AH.cbSrcLength = SrcBuffLen;
  AH.pbDst = pDestBuff;
  AH.cbDstLength = DestBuffLen;

  Rslt = acmStreamPrepareHeader (hCnvrtStream, &AH, 0);
  if (Rslt != MMSYSERR_NOERROR) 
	{
    LogMsg ("acmStreamPrepareHeader");
    return FALSE;
  }
  Rslt = acmStreamConvert (hCnvrtStream, &AH, ACM_STREAMCONVERTF_BLOCKALIGN);
  if (Rslt != MMSYSERR_NOERROR) 
	{
    switch( Rslt )
    {
      case 0:
        break; // success!
      case ACMERR_BUSY:
				LogMsg( "acmStreamConvert: ACMERR_BUSY" );
        break;
      case ACMERR_UNPREPARED:
				LogMsg( "acmStreamConvert: ACMERR_UNPREPARED" );
        break;
      case MMSYSERR_INVALFLAG:
				LogMsg( "acmStreamConvert: MMSYSERR_INVALFLAG" );
        break;
      case MMSYSERR_INVALHANDLE:
				LogMsg( "acmStreamConvert: MMSYSERR_INVALHANDLE" );
        break;
      case MMSYSERR_INVALPARAM:
				LogMsg( "acmStreamConvert: MMSYSERR_INVALPARAM" );
        break;
      default:
        LogMsg("Some error opening ACM decoding stream" );
        break;
        break;
    }
 //   LogMsg ("acmStreamPrepareHeader");
    return FALSE;
  }
	acmStreamUnprepareHeader (hCnvrtStream, &AH, 0);
	 
	ConvertedSamples= AH.cbSrcLengthUsed / BeepInfo.nBlockAlign;

	if (ConvertedSamples == NULL) 
	{
		return FALSE;
	}


	HANDLE hDestFile;
	DWORD BytesCnt;

//	hDestFile= CreateFile(FN, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_NO_BUFFERING, NULL); 
	hDestFile= CreateFile(FN, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_WRITE_THROUGH, NULL); 
	if (hDestFile == INVALID_HANDLE_VALUE)
	{
		LogErr("CreateFile: ADPCM");
	}

	*pTotalLenVal= 0x32+ AH.cbDstLengthUsed+ DestInfo.cbSize;
	*(DWORD *)&pBeepBuff[16]= sizeof(WAVEFORMATEX)+ DestInfo.cbSize;
	DestInfo.Ext[32]= 'd'; DestInfo.Ext[33]= 'a'; DestInfo.Ext[34]= 't'; DestInfo.Ext[35]= 'a'; 
	*(DWORD *)&DestInfo.Ext[36]= AH.cbDstLengthUsed;

	DestInfo.Ext[40]= 'f'; DestInfo.Ext[41]= 'a'; DestInfo.Ext[42]= 'c'; DestInfo.Ext[43]= 't'; 
	*(DWORD *)&DestInfo.Ext[44]= 4;
	*(DWORD *)&DestInfo.Ext[48]= ConvertedSamples;
	if (!WriteFile(hDestFile, pBeepBuff, 20, &BytesCnt, NULL) || (BytesCnt != 20))
	{
		LogErr("WriteFile: wav header");
	}
	if (!WriteFile(hDestFile, &DestInfo, sizeof(WAVEFORMATEX)+ DestInfo.cbSize+ 8, &BytesCnt, NULL) || (BytesCnt != sizeof(WAVEFORMATEX)+ DestInfo.cbSize+ 8))
	{
		LogErr("WriteFile: WAVEFORMATEX");
	}
  Ind= 0;
  do
	{
		if (AH.cbDstLengthUsed > 65535)
			i= 65535;
		else
			i= AH.cbDstLengthUsed;
		AH.cbDstLengthUsed-= i;
		if (!WriteFile(hDestFile, &pDestBuff[Ind], i, &BytesCnt, NULL) || (BytesCnt != i))
		{
			LogErr("WriteFile: pDestBuff");
			break;
		}		
		Ind+= i;
	}
	while (AH.cbDstLengthUsed > 0);
	if (!WriteFile(hDestFile, &DestInfo.Ext[40], 16, &BytesCnt, NULL) || (BytesCnt != 16))
	{
		LogErr("WriteFile: WAVEFORMATEX");
	}

	CloseHandle(hDestFile);
	LocalFree(pDestBuff);
 
  return S_OK;
}



