BOOL InitACM();
int ConvertToADPCM(TCHAR *FN, char *pSrcBuff, DWORD SrcBuffLen= 0);
void ClearACM();
