#include "mmsystem.h"

#pragma warning (disable: 4996)

#define WM_REFRESH_INFO						WM_USER+ 1
#define WM_PLAY_DONE							WM_USER+ 2
#define WM_DO_PAUSE		  					WM_USER+ 3
#define WM_DETECT_DONE						WM_USER+ 4
#define WM_TRIM_DONE							WM_USER+ 5
#define WM_BUILD_DONE							WM_USER+ 6
#define WM_LEVEL_BUILD_DONE				WM_USER+ 7
#define WM_LEVEL_REFRESH_INFO			WM_USER+ 8

#define MAX_BUFF_LEN			1024*1024*3*2+ 128					// 3 MB


int LoadFileToBuff(TCHAR *FileName, char **ppFileBuff);

int GetSampleBuff(char *pInFileBuff, int *pDataLen);
void GetFormatInfo(char *pBuff, WAVEFORMATEX *pFormat);
BOOL IsFormatMonoSign16pcm(WAVEFORMATEX *pFormat);