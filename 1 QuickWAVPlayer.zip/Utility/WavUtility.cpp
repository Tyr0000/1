#include "stdafx.h"
#include <math.h>
#include "WavUtility_.h"

#pragma comment(lib, "Winmm.lib")

#include "..\Utility\LogFile.h"

#ifdef _DEBUG
//#define _TEST
#endif

#ifdef _TEST
#include "F:\\Projects\\Common\\Utility\\ErrUtility.h"
#endif

int LoadFileToBuff(TCHAR *FileName, char **ppFileBuff)
{
  HANDLE hFile;
	char *pFileBuff= NULL;
	unsigned long FileSize, i;
	static unsigned long Len= 0;
#ifdef _TEST
	TCHAR Str[1024];
#endif

	hFile= CreateFile(FileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL); 
	if (hFile == INVALID_HANDLE_VALUE)
	{
#ifdef _TEST
		STR_CPY(Str, FileName);
		STR_CAT(Str, _T("\nImpossibly to read from file. Err code: #001"));
		::DsplErrMsg(Str);
#else
//		::MessageBox(::GetTopWindow(0), L"Impossibly to read from file.\nErr code: #001", L"Error", MB_OK | MB_ICONERROR);
#ifdef _UNICODE		
		LogMsg("%ws", FileName);
#else
		LogMsg("%s", FileName);
#endif
		LogErr("\tLoadFileToBuff: CreateFile");
#endif
		return INVALID_FILE_SIZE;
	}

	FileSize= GetFileSize(hFile, &i);
	if (FileSize == 0)
	{
		CloseHandle(hFile);
		return 0;
	}
	if (FileSize == INVALID_FILE_SIZE)
	{
#ifdef _TEST
		STR_CPY(Str, FileName);
		STR_CAT(Str, _T("\nImpossibly to read from file. Err code: #002"));
		::DsplErrMsg(Str);
#else
//		::MessageBox(::GetTopWindow(0), L"Impossibly to read from file.\nErr code: #002", L"Error", MB_OK | MB_ICONERROR);
    LogErr("LoadFileToBuff: GetFileSize");
#endif
		CloseHandle(hFile);
    return INVALID_FILE_SIZE;
	}
/*	
	if (FileSize > MAX_BUFF_LEN)
	{
		::MessageBox(::GetTopWindow(0), L"File is too long", L"Error", MB_OK | MB_ICONERROR);
		CloseHandle(hFile);
    return INVALID_FILE_SIZE;
	}
*/
	if ((Len == 0) || (*ppFileBuff == NULL))
	{
		if (FileSize < MAX_BUFF_LEN)
			Len= MAX_BUFF_LEN;
		else
			Len= FileSize;
		pFileBuff= (char *)LocalAlloc(LMEM_FIXED, Len+ 4);
	}
	else
		if (Len < FileSize)
		{
			if (*ppFileBuff != NULL)
				LocalFree(pFileBuff);
			Len= FileSize;
			pFileBuff= (char *)LocalAlloc(LMEM_FIXED, Len+ 4);
		}
		else
			pFileBuff= *ppFileBuff;

	if ((!ReadFile(hFile, pFileBuff, FileSize, &i, NULL)) || (i != FileSize))
	{
		CloseHandle(hFile);
#ifdef _TEST
		STR_CPY(Str, FileName);
		STR_CAT(Str, _T("\nImpossibly to read from file. Err code: #003"));
		::DsplErrMsg(Str);
#else
//		::MessageBox(::GetTopWindow(0), L"Impossibly to read from file.\nErr code: #003", L"Error", MB_OK | MB_ICONERROR);
    LogErr("LoadFileToBuff: ReadFile");
#endif
		return INVALID_FILE_SIZE;
	}
	CloseHandle(hFile);
  *ppFileBuff= pFileBuff;
	return FileSize;
}

int GetSampleBuff(char *pInFileBuff, int *pDataLen)
{
	DWORD ChunkSize;
	int DataInd= 0;

	ChunkSize=			 *(DWORD *)&pInFileBuff[16];
/*
	FormatTag=			 *(WORD *)&pInFileBuff[20]; 
	NumChannels=		 *(WORD *)&pInFileBuff[22]; 
	SamplesPerSec=	 *(DWORD *)&pInFileBuff[24]; 
	AvgBytesPerSec=	 *(DWORD *)&pInFileBuff[28]; 
	BlockAlign=			 *(WORD *)&pInFileBuff[32]; 
	BitsPerSample=   *(WORD *)&pInFileBuff[34]; 
*/
	DataInd= 16+ ChunkSize;
	while (*(DWORD *)&pInFileBuff[DataInd] != 0x61746164) // "data", skip additional header
		DataInd++;
	ChunkSize=			*(DWORD *)&pInFileBuff[DataInd+ 4];	// data length
  DataInd+= 8;
/*
	if ((*(WORD *)&pInFileBuff[20] == WAVE_FORMAT_PCM) &&
		  (*(WORD *)&pInFileBuff[34] ==	16))
		ChunkSize/= 2;
*/
	*pDataLen= ChunkSize;

	return DataInd;
}

void GetFormatInfo(char *pBuff, WAVEFORMATEX *pFormat)
{
	DWORD ChunkSize;
	int DataInd= 0;

	ChunkSize= *(DWORD *)&pBuff[16];

	DataInd= 16+ ChunkSize;
	while (*(DWORD *)&pBuff[DataInd] != 0x61746164) // "data", skip additional header
		DataInd++;
	ChunkSize=	*(DWORD *)&pBuff[DataInd+ 4];	// data length

	pFormat->wFormatTag=				*(WORD *)&pBuff[20];				// WAVE_FORMAT_PCM;
	pFormat->nAvgBytesPerSec=		*(DWORD *)&pBuff[28];				// 16000;
	pFormat->nBlockAlign=				*(WORD *)&pBuff[32];				// 2;
	pFormat->nChannels=					*(WORD *)&pBuff[22];				// 1;
	pFormat->nSamplesPerSec=		*(DWORD *)&pBuff[24];				// 8000;
  pFormat->wBitsPerSample=		*(WORD *)&pBuff[34];				//16;
//	pFormat->cbSize=						ChunkSize;
}

BOOL IsFormatMonoSign16pcm(WAVEFORMATEX *pFormat)
{
	if ((pFormat->wFormatTag     ==	WAVE_FORMAT_PCM) &&
//			(pFormat->nBlockAlign    ==	2) &&
			(pFormat->nChannels		   ==	1) &&
			(pFormat->wBitsPerSample ==	16))
		return TRUE;
	else
	{
//		MessageBox(0, _T("This format is not supported to skip silence or detect no sound"), _T("Attention"), MB_ICONEXCLAMATION | MB_OK);
		return FALSE;
	}
}

