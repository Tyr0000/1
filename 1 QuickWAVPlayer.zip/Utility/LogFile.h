#include <windows.h>
#include <stdio.h>
#include "uTchar.h"

#ifndef _LOG_FILE_SRC
#ifdef _DEBUG
#pragma comment (lib, "LogFile_d.lib")
#else
#pragma comment (lib, "LogFile.lib")
#endif
#endif

#ifndef TOP_WND
#define TOP_WND GetTopWindow(0)
#endif

#pragma once

extern CRITICAL_SECTION LogCrSect;

#define IFDEF #ifdef
#define IFDEF_DEBUG #ifdef _DEBUG
#define ENDIF #endif

#define IFDEF_HISTORY #ifdef _HISTORY
#define IFDEF_LOG IFDEF _LOG

#ifdef _LOG
#define INIT_LOG_FILE(FN, hModule)\
	InitLogFile(FN, hModule);
#else
#endif
/*
#ifdef _LOG
#define INIT_LOG_FILE(FN)\
	InitLogFile(FN);
#else
#define INIT_LOG_FILE(FN) ;
#endif
*/
#ifdef _LOG
#define SAFE_LOG_MSG(Msg)\
{\
	EnterCriticalSection(&LogCrSect);\
	LogMsg(Msg);\
	LeaveCriticalSection(&LogCrSect);\
}
#else
#define SAFE_LOG_MSG(Msg) ;
#endif

#ifdef _LOG
#define SAFE_LOG_ERR(Msg)\
{\
	EnterCriticalSection(&LogCrSect);\
	LogErr(Msg);\
	LeaveCriticalSection(&LogCrSect);\
}
#else
#define SAFE_LOG_ERR(Msg) ;
#endif

#ifdef _LOG
#define SAFE_LOG_HEX(Buff, Len)\
{\
	EnterCriticalSection(&LogCrSect);\
	LogHex((BYTE *)Buff, Len);\
	LeaveCriticalSection(&LogCrSect);\
}
#else
#define SAFE_LOG_ERR(Msg) ;
#endif

#ifdef _LOG
#define LOG_MSG(Msg)\
	LogMsg(Msg);
#else
#define LOG_MSG(Msg) ;
#endif

#ifdef _LOG
#define LOG_ERR(Msg)\
	LogErr(Msg);
#else
// #define LOG_ERR(Msg) ;
#endif


#ifdef _LOG
#define LOG_WSAERR(Msg) LogWSAErr(Msg);
#else
#define LOG_WSAERR(Msg) ;
#endif


#ifdef _LOG
#define LOG_BUFF(Buff, Size)\
	LogBuff((BYTE *)Buff, Size);
#define LOG_HEX(Buff, Size)\
	LogHex((BYTE *)Buff, Size);
#else
#define LOG_BUFF ;
#define LOG_HEX ;
#endif

#ifdef _LOG
#define LOG_WM(WinMsg)\
    LogMsg(#WinMsg"\t%i\t%i\n", wParam, lParam);
#else
#define LOG_MSG(WinMsg) ;
#endif

extern
FILE *LogFile;
extern 
char log_file_name[MAX_PATH+ 1];
extern
size_t log_file_name_len;
extern
size_t FileSize;
extern
long Ind;


void InitTimeLogFile(TCHAR *FN);
void InitLogFile(TCHAR *FN= NULL, HMODULE hModule= NULL);
//void InitLogFile(char *FN= NULL, int *OpenOpt= -1, HMODULE hModule= NULL);
void SwitchLogFile();
void CloseLogFile();

void LogWchar(WCHAR *Buff, int Size= 0);
void LogBuff(BYTE *Buff, int Size);
void LogHex(BYTE *pBuff, int Size);
void LogMsg(const char *szMsg, ... );
void LogWSAErr(char *Function);
void LogTimeMsg(const char *szMsg, ... );
void LogStartMsg(const char *szMsg, ... );
void LogStopMsg(const char *szMsg, ... );
void LogTbl(char *Buff, int Columns, int Rows);
void LogHexTbl(char *Buff, int Columns, int Rows);

#ifdef _DEBUG
void DbgMsg(const char *szMsg, ... );
#endif

void LogErr(char *Function);
void LogWinMsg(UINT message, WPARAM wParam, LPARAM lParam);
char *TraceWinMsg(UINT message, WPARAM wParam, LPARAM lParam);

#define D_InitLogFile(FN)\
IFDEF_DEBUG\
	InitLogFile(FN);\
ENDIF

#define D_DbgMsg(FN)\
IFDEF_DEBUG \
	DbgMsg(szMsg);\
ENDIF




