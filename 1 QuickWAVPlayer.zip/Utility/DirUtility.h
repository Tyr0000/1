#pragma once

typedef struct _FILE_ENTRY
{
//	int Ind;
	BOOL IsSelected;
	void *pNextEntry;
//	void *pSortedEntry;
	int Val;
	int Len;
#ifdef _BUILDER
	HANDLE hFile;
	int Duration;
	DWORD DataOffset;
	int DataLen;
#endif
	TCHAR FN[1];
} FILE_ENTRY; //, FILE_LIST;

typedef struct _FILE_LIST // : public FILE_ENTRY
{
	FILE_ENTRY *m_pFileList;
	_FILE_LIST(){m_pFileList= NULL;};
	~_FILE_LIST(){ClearFileList();};
	void ClearFileList();
	BOOL GetFileList(TCHAR *pWorkDir);
} FILE_LIST;

void ClearFileList();
FILE_ENTRY *GetFileList(TCHAR *pWorkDir);
