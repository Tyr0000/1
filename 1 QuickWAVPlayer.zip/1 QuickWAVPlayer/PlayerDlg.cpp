// PlayerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Player.h"
#include "PlayerDlg.h"

#include "..\Utility\WavUtility.h"
#include "..\Utility\PlayerUtility.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPlayerDlg dialog

#define THRESHOLD_BASE_IND			5

// TCHAR WorkDir[MAX_PATH+ 1];
DWORD StayOnTop;
BOOL IsClosed= FALSE;

//int ThresholdInd= 5;
static PLAYER_MODE PlayerMode= PM_WAIT;
TCHAR IniPath[MAX_PATH+ 1]; 
BOOL FromBegining;

static FILE_ENTRY *pFileList, *pFileEntry= NULL;

CPlayerDlg::CPlayerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPlayerDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPlayerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, Lst1);
}

BEGIN_MESSAGE_MAP(CPlayerDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON_PLAY, &CPlayerDlg::OnBnClickedButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_PAUSE, &CPlayerDlg::OnBnClickedButtonPause)
	ON_BN_CLICKED(IDC_BUTTON_STOP, &CPlayerDlg::OnBnClickedButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_MARK, &CPlayerDlg::OnBnClickedButtonMark)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, &CPlayerDlg::OnBnClickedButtonBrowse)
	ON_BN_CLICKED(IDC_CHECK_SKIP_SILENCE, &CPlayerDlg::OnBnClickedCheckSkipSilence)
	ON_BN_CLICKED(IDC_CHECK_FROM_BEGINING, &CPlayerDlg::OnBnClickedCheckFromBegining)
	ON_CBN_SELCHANGE(IDC_COMBO_THRESHOLD_RATIO, &CPlayerDlg::OnCbnSelchangeComboThresholdRatio)
	ON_WM_DESTROY()
//	ON_BN_CLICKED(IDC_BUTTON1, &CPlayerDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_RADIO1, &CPlayerDlg::OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_RADIO2, &CPlayerDlg::OnBnClickedRadio2)
	ON_BN_CLICKED(IDC_BUTTON_COPY, &CPlayerDlg::OnBnClickedButtonCopy)
//	ON_EN_KILLFOCUS(IDC_EDIT_DIR, &CPlayerDlg::OnEnKillfocusEditDir)
	ON_EN_CHANGE(IDC_EDIT_DIR, &CPlayerDlg::OnEnChangeEditDir)
	ON_BN_CLICKED(IDC_CHECK_STAY_ON_TOP, &CPlayerDlg::OnBnClickedCheckStayOnTop)
END_MESSAGE_MAP()


// CPlayerDlg message handlers

void CPlayerDlg::EnablePlayingModeBttns()
{
	GetDlgItem(IDC_BUTTON_PLAY)->EnableWindow(FALSE);
 	if (PlayerMode == PM_WAIT)
	{
		SetDlgItemText(IDC_BUTTON_PLAY, L"Play");
  	GetDlgItem(IDC_BUTTON_COPY)->EnableWindow(FALSE);
	}
	else
	{
		SetDlgItemText(IDC_BUTTON_PLAY, L"Continue");
  	GetDlgItem(IDC_BUTTON_COPY)->EnableWindow();
	}
  if (PlayerMode != PM_PLAYING)
		GetDlgItem(IDC_BUTTON_COPY)->EnableWindow();
	else
		GetDlgItem(IDC_BUTTON_COPY)->EnableWindow(FALSE);

	GetDlgItem(IDC_BUTTON_STOP)->EnableWindow();
	GetDlgItem(IDC_BUTTON_PAUSE)->EnableWindow();
	GetDlgItem(IDC_BUTTON_MARK)->EnableWindow();

	GetDlgItem(IDC_BUTTON_BROWSE)->EnableWindow(FALSE);

	SetForegroundWindow();
	SetFocus();
}

void CPlayerDlg::DisablePlayingModeBttns()
{
	GetDlgItem(IDC_BUTTON_PLAY)->EnableWindow();
 	if (PlayerMode == PM_WAIT)
	{
		SetDlgItemText(IDC_BUTTON_PLAY, L"Play");
  	GetDlgItem(IDC_BUTTON_BROWSE)->EnableWindow();
	}
	else
	{
		SetDlgItemText(IDC_BUTTON_PLAY, L"Continue");
	}
	if (PlayerMode == PM_WAIT)
		GetDlgItem(IDC_BUTTON_STOP)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_PAUSE)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_MARK)->EnableWindow(FALSE);
	GetDlgItem(IDC_BUTTON_COPY)->EnableWindow();

	SetForegroundWindow();
	SetFocus();
}

void CPlayerDlg::DisableOptionCntrls()
{
	GetDlgItem(IDC_EDIT_DIR)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECK_STAY_ON_TOP)->EnableWindow(FALSE);
	GetDlgItem(IDC_CHECK_FROM_BEGINING)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_FROM)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO1)->EnableWindow(FALSE);
	GetDlgItem(IDC_RADIO2)->EnableWindow(FALSE);
	if (PlayContinuonesly)
		GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow(FALSE);
	else
		GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow();
}

void CPlayerDlg::EnableOptionCntrls()
{
	GetDlgItem(IDC_EDIT_DIR)->EnableWindow();
	GetDlgItem(IDC_CHECK_STAY_ON_TOP)->EnableWindow();
	GetDlgItem(IDC_CHECK_FROM_BEGINING)->EnableWindow();
	if (FromBegining)
		GetDlgItem(IDC_EDIT_FROM)->EnableWindow(FALSE);
	else
		GetDlgItem(IDC_EDIT_FROM)->EnableWindow();	
	GetDlgItem(IDC_RADIO1)->EnableWindow();
	GetDlgItem(IDC_RADIO2)->EnableWindow();
	if (PlayContinuonesly)
		GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow(FALSE);
	else
		GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow();
}

BOOL CPlayerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

  DisablePlayingModeBttns();

	::GetCurrentDirectory(MAX_PATH+ 1, IniPath);
	wcscat(IniPath, L"\\Options.ini");

	((CButton *)GetDlgItem(IDC_CHECK_FROM_BEGINING))->SetCheck(TRUE);
	GetDlgItem(IDC_EDIT_FROM)->EnableWindow(FALSE);
	((CButton *)GetDlgItem(IDC_CHECK_SKIP_SILENCE))->SetCheck(TRUE);
	((CComboBox *)GetDlgItem(IDC_COMBO_THRESHOLD_RATIO))->SetCurSel(THRESHOLD_BASE_IND);
	((CButton *)GetDlgItem(IDC_RADIO1))->SetCheck(TRUE);
	GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow(FALSE);

	StayOnTop= ::GetPrivateProfileInt(L"General", L"StayOnTop", 0, IniPath);
	::SetWindowPos(m_hWnd, HWND(0xFFFFFFFF- (StayOnTop ^ 1)), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
	((CButton *)GetDlgItem(IDC_CHECK_STAY_ON_TOP))->SetCheck(StayOnTop); 

	SkipSilence= TRUE;
	FromBegining= TRUE;
  PlayContinuonesly= TRUE;

//	SetDlgItemText(IDC_EDIT_DIR, WorkDir);
//	SetDlgItemText(IDC_EDIT_DIR, L"e:\\Src\\Quick Wav Player\\Data ");

	if (!InitPlayerParams(m_hWnd))
	{
  	GetDlgItem(IDC_BUTTON_PLAY)->EnableWindow(FALSE);
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPlayerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPlayerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CPlayerDlg::OnBnClickedButtonPlay()
{
//	CWaitCursor WaitCursor;

	int Val;
	char ValStr[16];

	if (PlayerMode >= PM_PAUSED)
		SetEvent(hResumeEvnt);
	else
	{
		GetDlgItemText(IDC_EDIT_DIR, PlayDir, MAX_PATH+ 1);
		pFileList= GetFileList(PlayDir);
		if (pFileList == NULL)
			return;
			pPlayFileList= pFileList;
		if (!FromBegining)
		{ 
			GetDlgItemTextA(m_hWnd, IDC_EDIT_FROM, ValStr, 16);
			Val= atoi(ValStr);
			while ((pPlayFileList != NULL) && (pPlayFileList->Val != Val))
				pPlayFileList= (FILE_ENTRY *)pPlayFileList->pNextEntry;
			if (pPlayFileList == NULL)
			{
				::MessageBox(0, L"Wrong file number to start playing from.\nEnter another one and try again", L"Error", MB_OK);
				return;
			}
		}
		if (!PlayContinuonesly)
		{
			GetDlgItemTextA(m_hWnd, IDC_EDIT_PRELOADED_NUM, ValStr, 16);
			SeriesLen= atoi(ValStr);
		}
		if (!StartPlayer())
			return;
	}
	PlayerMode= PM_PLAYING;
	EnablePlayingModeBttns();
	DisableOptionCntrls();
	Lst1.ResetContent();
}

void CPlayerDlg::OnBnClickedButtonPause()
{
	CWaitCursor WaitCursor;
//	SetEvent(hPauseEvnt);
  PausePlayer();

	PlayerMode= PM_PAUSED;
	DisablePlayingModeBttns();

	FILE_ENTRY *pTmpEntry;
 
  pTmpEntry= pFileList;
	Lst1.ResetContent();
	while (pTmpEntry != NULL)
	{
		if (pTmpEntry->IsSelected)
			Lst1.AddString(pTmpEntry->FN);
		pTmpEntry= (FILE_ENTRY *)pTmpEntry->pNextEntry;
	}
}

void CPlayerDlg::OnBnClickedButtonStop()
{
	CWaitCursor WaitCursor;

	if (PlayerMode != PM_WAIT)
		StopPlayer();

	if (PlayerMode == PM_PLAYING)
	{
		FILE_ENTRY *pTmpEntry;
 
		Lst1.ResetContent();
		pTmpEntry= pFileList;
		while (pTmpEntry != NULL)
		{
			if (pTmpEntry->IsSelected)
				Lst1.AddString(pTmpEntry->FN);
			pTmpEntry= (FILE_ENTRY *)pTmpEntry->pNextEntry;
		}
	}
	PlayerMode= PM_WAIT;
	DisablePlayingModeBttns();
	EnableOptionCntrls();

	SetDlgItemText(IDC_STATIC_CURRENT_FILE, L"0");

	SaveOptions();
}

void CPlayerDlg::OnBnClickedButtonMark()
{
 	if ((pFileEntry != NULL) && (PlayerMode == PM_PLAYING))
	{
		pFileEntry->IsSelected= TRUE;
		Lst1.AddString(pFileEntry->FN);
		Lst1.RedrawWindow(0, 0, RDW_ERASE | RDW_INVALIDATE | RDW_INTERNALPAINT | RDW_ERASENOW | RDW_UPDATENOW);
	}
}

int CALLBACK BrowseCallbackProc (HWND hWnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
    TCHAR szPath[_MAX_PATH];

    switch (uMsg) 
		{
    case BFFM_INITIALIZED:
        if (lpData)
            SendMessage(hWnd,BFFM_SETSELECTION,TRUE,lpData);
        break;
    case BFFM_SELCHANGED:
        SHGetPathFromIDList(LPITEMIDLIST(lParam),szPath);
        SendMessage(hWnd, BFFM_SETSTATUSTEXT, NULL, LPARAM(szPath));
        break;
    }
    return 0;
}

void CPlayerDlg::OnBnClickedButtonBrowse()
{
    LPMALLOC pMalloc;
    if (::SHGetMalloc(&pMalloc) == NOERROR) 
		{
        BROWSEINFO bi;
        ::ZeroMemory(&bi,sizeof bi);
        bi.ulFlags = BIF_RETURNONLYFSDIRS;
				// ����������� �������� ��������
				bi.lpfn      = BrowseCallbackProc;
        bi.ulFlags  |= BIF_STATUSTEXT;

				// ��������� �������� �� ���������
				bi.lParam    = LPARAM(PlayDir);
      
        // ���������� ��������� � �������
        bi.lpszTitle = L"Select a wav files directory to play";

				bi.hwndOwner = m_hWnd;

				LPITEMIDLIST pidl = ::SHBrowseForFolder(&bi);

        if (pidl != NULL) {
            if (::SHGetPathFromIDList(pidl, PlayDir))
            pMalloc->Free(pidl);
        }
        pMalloc->Release();
		}
	SetDlgItemText(IDC_EDIT_DIR, PlayDir);
//	GetDlgItem(IDC_EDIT_DIR)->SetFocus();
}

void CPlayerDlg::OnBnClickedRadio1()
{
	if (PlayContinuonesly)
		return;

	PlayContinuonesly^= 1;
	SeriesLen= 0;

	if (PlayContinuonesly)
		GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow(FALSE);
	else
		GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow();
}

void CPlayerDlg::OnBnClickedRadio2()
{
	if (!PlayContinuonesly)
		return;

	PlayContinuonesly^= 1;

	if (PlayContinuonesly)
		GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow(FALSE);
	else
		GetDlgItem(IDC_EDIT_PRELOADED_NUM)->EnableWindow();
}

void CPlayerDlg::OnBnClickedCheckSkipSilence()
{
	SkipSilence^= 1;

	if (SkipSilence)
		GetDlgItem(IDC_COMBO_THRESHOLD_RATIO)->EnableWindow();
	else
		GetDlgItem(IDC_COMBO_THRESHOLD_RATIO)->EnableWindow(FALSE);
}

void CPlayerDlg::OnBnClickedCheckFromBegining()
{
	FromBegining^= 1;

	if (FromBegining)
	{
		GetDlgItem(IDC_EDIT_FROM)->EnableWindow(FALSE);
		SetDlgItemText(IDC_EDIT_FROM, L"");
	}
	else
		GetDlgItem(IDC_EDIT_FROM)->EnableWindow();
}

void CPlayerDlg::OnCbnSelchangeComboThresholdRatio()
{
	ThresholdRatio= THRESHOLD_BASE_IND- ((CComboBox *)GetDlgItem(IDC_COMBO_THRESHOLD_RATIO))->GetCurSel();
}

void CPlayerDlg::OnDestroy()
{
	TCHAR ValStr[32]= {L'1'};

	IsClosed= TRUE;

	CDialog::OnDestroy();

	ClearFileList();
	StopPlayer();
	ClearPlayerParams();

	StayOnTop+= 0x30;
	::WritePrivateProfileString(L"General", L"StayOnTop", (TCHAR *)&StayOnTop, IniPath);
}

BOOL CPlayerDlg::PreTranslateMessage(MSG* pMsg)
{
	switch (pMsg->message)
	{
 		case WM_KEYDOWN:
 			switch (pMsg->wParam)
			{
				case VK_ESCAPE:
					return 1;
				case VK_RETURN:
				case VK_SPACE:
 					if ((pFileEntry != NULL) && (PlayerMode == PM_PLAYING))
					{
						pFileEntry->IsSelected= TRUE;
						Lst1.AddString(pFileEntry->FN);
						Lst1.RedrawWindow(0, 0, RDW_ERASE | RDW_INVALIDATE | RDW_INTERNALPAINT | RDW_ERASENOW | RDW_UPDATENOW);
  					return 1;	
					}
			}
		break;
		case WM_KEYUP:
				case VK_ESCAPE:
				case VK_RETURN:
				case VK_SPACE:
					return 1;
		break;
	}

	return CDialog::PreTranslateMessage(pMsg);
}

LRESULT CPlayerDlg::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	if (IsClosed)
		return 0;

	switch(message)
	{
		case WM_REFRESH_INFO:
			SetDlgItemText(IDC_STATIC_CURRENT_FILE, (TCHAR *)wParam);
			pFileEntry= (FILE_ENTRY *)lParam;
			return 0;
		
		case WM_PLAY_DONE:
			OnBnClickedButtonStop();
			return 0;

		case WM_DO_PAUSE:
			PlayerMode= PM_PAUSED;
			DisablePlayingModeBttns();
		return 0;
	}

	return CDialog::DefWindowProc(message, wParam, lParam);
}

void CPlayerDlg::OnBnClickedButtonCopy()
{
	HGLOBAL hData;
	char *pData;
  int Len= 0;
	FILE_ENTRY *pTmpEntry;
/*
	if (PlayerMode == PM_PLAYING)
	{
		::MessageBox(m_hWnd, L"Stop or Pause player and try again", L"Error", MB_OK);
		return;
	}
*/
	if (pFileList == NULL)
		return;

	Lst1.ResetContent();
	pTmpEntry= pFileList;
	while (pTmpEntry != NULL)
	{
		if (pTmpEntry->IsSelected)
			Len+= pTmpEntry->Len+ 2;  // 0 0x0D0A 0
		pTmpEntry= (FILE_ENTRY *)pTmpEntry->pNextEntry;
	}
	if (Len == 0)
		return;
	Len++;
	Len*=  sizeof(TCHAR);
  hData= GlobalAlloc(GMEM_MOVEABLE, Len);
  if (hData == NULL) 
  { 
    return; 
  } 
	pData= (char *)GlobalLock(hData); 
  pTmpEntry= pFileList;
	while (pTmpEntry != NULL)
	{
		if (pTmpEntry->IsSelected)
		{
			wcscpy((TCHAR *)pData, pTmpEntry->FN);
			pData+= (pTmpEntry->Len)*sizeof(TCHAR);
			*(DWORD *)pData= 0x000A000D;
			pData+= 4;
			pTmpEntry->IsSelected= FALSE;
			Lst1.AddString(pTmpEntry->FN);
		}
		pTmpEntry= (FILE_ENTRY *)pTmpEntry->pNextEntry;
	}
		*(WORD *)pData= 0;
	GlobalUnlock(hData); 
  
	if (!::OpenClipboard(m_hWnd)) 
	{
		::MessageBox(0, L"Impossibly to open clipboard", L"Error", MB_OK);
		GlobalFree(hData);
		return; 
	}
	EmptyClipboard(); 
	SetClipboardData(CF_UNICODETEXT, hData); 
	CloseClipboard(); 
}

//void CPlayerDlg::OnEnKillfocusEditDir()
//{
//}

void CPlayerDlg::OnEnChangeEditDir()
{
	TCHAR Str[32];
	int Val;

	GetDlgItemText(IDC_EDIT_DIR, PlayDir, MAX_PATH+ 1);

	Val= ::GetFileAttributes(PlayDir);
	if (Val == INVALID_FILE_ATTRIBUTES)
		return;
	Val&= FILE_ATTRIBUTE_DIRECTORY;
	if (Val == 0)
		return;

	Val= ::GetPrivateProfileInt(PlayDir, L"Ratio", 1000, IniPath);
	if (Val == 1000)
  	return; 

	ThresholdRatio= Val;
	if (ThresholdRatio == 100)
	{
		((CButton *)GetDlgItem(IDC_CHECK_SKIP_SILENCE))->SetCheck(FALSE);
		SkipSilence= FALSE;
		((CComboBox *)GetDlgItem(IDC_COMBO_THRESHOLD_RATIO))->SetCurSel(THRESHOLD_BASE_IND);
		ThresholdRatio= 0;
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_SKIP_SILENCE))->SetCheck(TRUE);
  	SkipSilence= TRUE;
		((CComboBox *)GetDlgItem(IDC_COMBO_THRESHOLD_RATIO))->SetCurSel(THRESHOLD_BASE_IND- ThresholdRatio);
	}

	::GetPrivateProfileString(PlayDir, L"From", L"0", Str, 32, IniPath);
	if (Str[0] != '0')
	{
		((CButton *)GetDlgItem(IDC_CHECK_FROM_BEGINING))->SetCheck(FALSE);
		FromBegining= FALSE;
		GetDlgItem(IDC_EDIT_FROM)->EnableWindow();
		SetDlgItemText(IDC_EDIT_FROM, Str);
	}
	else
	{
		((CButton *)GetDlgItem(IDC_CHECK_FROM_BEGINING))->SetCheck(TRUE);
		FromBegining= TRUE;
		SetDlgItemText(IDC_EDIT_FROM, L"");
		GetDlgItem(IDC_EDIT_FROM)->EnableWindow(FALSE);
	}
}

void CPlayerDlg::SaveOptions()
{
	TCHAR Str[32];

	if (!SkipSilence)
		::WritePrivateProfileString(PlayDir, L"Ratio", L"100", IniPath);
	else
	{
		GetDlgItemText(IDC_COMBO_THRESHOLD_RATIO, Str, 32);
		::WritePrivateProfileString(PlayDir, L"Ratio", Str, IniPath);
	}

	if ((pFileEntry->pNextEntry == NULL) || (pFileEntry->pNextEntry == NULL))
		::WritePrivateProfileString(PlayDir, L"From", L"0", IniPath);
	
	if ((pFileEntry != NULL) && (pFileEntry->pNextEntry != NULL))
	{
		wsprintf(Str, L"%i", ((FILE_ENTRY *)pFileEntry->pNextEntry)->Val+ 1);
		::WritePrivateProfileString(PlayDir, L"From", Str, IniPath);
	}
}

void CPlayerDlg::OnBnClickedCheckStayOnTop()
{
	::SetWindowPos(m_hWnd, HWND(0xFFFFFFFF- (StayOnTop)), 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
	StayOnTop^= 1;
}
