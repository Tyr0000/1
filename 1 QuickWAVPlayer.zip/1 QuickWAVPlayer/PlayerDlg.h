// PlayerDlg.h : header file
//

#pragma once


// CPlayerDlg dialog
class CPlayerDlg : public CDialog
{
// Construction
public:
	CPlayerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_PLAYER_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	void DisablePlayingModeBttns();
	void EnablePlayingModeBttns();
	void DisableOptionCntrls();
	void EnableOptionCntrls();

	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonPlay();
public:
	afx_msg void OnBnClickedButtonPause();
public:
	afx_msg void OnBnClickedButtonStop();
public:
	afx_msg void OnBnClickedButtonMark();
public:
	afx_msg void OnBnClickedButtonBrowse();
public:
	afx_msg void OnBnClickedCheckSkipSilence();
public:
	afx_msg void OnBnClickedCheckFromBegining();
public:
	afx_msg void OnCbnSelchangeComboThresholdRatio();
public:
	afx_msg void OnDestroy();
protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	CListBox Lst1;
public:
	afx_msg void OnBnClickedButton1();
public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
public:
	afx_msg void OnBnClickedRadio1();
public:
	afx_msg void OnBnClickedRadio2();
public:
	afx_msg void OnBnClickedButtonCopy();
public:
//	afx_msg void OnEnKillfocusEditDir();
public:
	afx_msg void OnEnChangeEditDir();
public:
	void SaveOptions();
public:
	afx_msg void OnBnClickedCheckStayOnTop();
};
